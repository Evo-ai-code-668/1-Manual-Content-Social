"use client"

import { CardFooter } from "@/components/ui/card"

import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "@/components/ui/dropdown-menu"

import { useState, useEffect, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import {
  Plus,
  Eye,
  Trash2,
  Upload,
  FolderOpen,
  ChevronDown,
  Filter,
  ChevronLeft,
  ChevronRight,
  Search,
  X,
  CheckCircle,
  Lock,
  Clock,
  Save,
  ChevronsLeft,
  ChevronsRight,
  Check,
  User,
  Calendar,
  Pencil,
  FileImage,
  Play,
  GripVertical,
  ImageIcon,
  Instagram,
  FileText,
  Film,
  Info,
  FileX,
  Layers,
  StopCircle,
  PlayCircle,
  Shuffle,
} from "lucide-react"

// MultiSelect component removed - using native Select with manual toggle instead

// Social platforms and their usernames
const socialPlatforms = {
  instagram: {
    icon: "📷",
    name: "Instagram",
  },
  threads: {
    icon: "🧵",
    name: "Threads",
  },
  facebook: {
    icon: "👥",
    name: "Facebook",
  },
  x: {
    icon: "🐦",
    name: "X",
  },
  tiktok: {
    icon: "🎵",
    name: "TikTok",
  },
  pinterest: {
    icon: "📌",
    name: "Pinterest",
  },
  youtube: {
    icon: "📺",
    name: "YouTube",
  },
  linkedin: {
    icon: "💼",
    name: "LinkedIn",
  },
  medium: {
    icon: "✍️",
    name: "Medium",
  },
  reddit: {
    icon: "🤖",
    name: "Reddit",
  },
  tumblr: {
    icon: "🎨",
    name: "Tumblr",
  },
  quora: {
    icon: "❓",
    name: "Quora",
  },
}

// Platform colors and icons
const platformConfig = {
  instagram: {
    color: "bg-gradient-to-r from-purple-500 to-pink-500",
    textColor: "text-purple-600",
    bgColor: "bg-purple-50",
    icon: "📷",
    name: "Instagram",
  },
  threads: {
    color: "bg-black",
    textColor: "text-gray-800",
    bgColor: "bg-gray-50",
    icon: "🧵",
    name: "Threads",
  },
  facebook: {
    color: "bg-blue-600",
    textColor: "text-blue-600",
    bgColor: "bg-blue-50",
    icon: "👥",
    name: "Facebook",
  },
  x: {
    color: "bg-black",
    textColor: "text-gray-800",
    bgColor: "bg-gray-50",
    icon: "🐦",
    name: "X",
  },
  tiktok: {
    color: "bg-black",
    textColor: "text-gray-800",
    bgColor: "bg-gray-50",
    icon: "🎵",
    name: "TikTok",
  },
  youtube: {
    color: "bg-red-600",
    textColor: "text-red-600",
    bgColor: "bg-red-50",
    icon: "📺",
    name: "YouTube",
  },
  linkedin: {
    color: "bg-blue-700",
    textColor: "text-blue-700",
    bgColor: "bg-blue-50",
    icon: "💼",
    name: "LinkedIn",
  },
  pinterest: {
    color: "bg-red-500",
    textColor: "text-red-500",
    bgColor: "bg-red-50",
    icon: "📌",
    name: "Pinterest",
  },
  medium: {
    color: "bg-gray-800",
    textColor: "text-gray-800",
    bgColor: "bg-gray-50",
    icon: "✍️",
    name: "Medium",
  },
  reddit: {
    color: "bg-orange-500",
    textColor: "text-orange-500",
    bgColor: "bg-orange-50",
    icon: "🤖",
    name: "Reddit",
  },
  tumblr: {
    color: "bg-indigo-600",
    textColor: "text-indigo-600",
    bgColor: "bg-indigo-50",
    icon: "🎨",
    name: "Tumblr",
  },
  quora: {
    color: "bg-red-700",
    textColor: "text-red-700",
    bgColor: "bg-red-50",
    icon: "❓",
    name: "Quora",
  },
}

// Status configuration
const statusConfig = {
  Active: {
    color: "bg-green-500",
    textColor: "text-green-700",
    bgColor: "bg-green-50",
    icon: CheckCircle,
    name: "Active",
  },
  Locker: {
    color: "bg-red-500",
    textColor: "text-red-700",
    bgColor: "bg-red-50",
    icon: Lock,
    name: "Locker",
  },
  Pending: {
    color: "bg-yellow-500",
    textColor: "text-yellow-700",
    bgColor: "bg-yellow-50",
    icon: Clock,
    name: "Pending",
  },
}

// Auto-sync data based on idea and niche combinations
const autoSyncData = {
  "Wild Cats": {
    "African Safari": {
      type: "NTM",
      department: "Wildlife Department",
      team: "Safari Team",
      leader: "Wildlife Photography",
    },
    "Asian Tigers": {
      type: "TM",
      department: "Conservation Department",
      team: "Tiger Protection",
      leader: "Tiger Research",
    },
    "Mountain Lions": {
      type: "NTM",
      department: "Mountain Department",
      team: "Predator Team",
      leader: "Mountain Wildlife",
    },
  },
  "Ocean Mammals": {
    "Deep Sea Giants": {
      type: "TM",
      department: "Marine Department",
      team: "Deep Sea Research",
      leader: "Marine Biology",
    },
    "Coastal Dolphins": {
      type: "NTM",
      department: "Coastal Department",
      team: "Dolphin Study",
      leader: "Dolphin Behavior",
    },
    "Arctic Seals": {
      type: "TM",
      department: "Arctic Department",
      team: "Seal Conservation",
      leader: "Arctic Marine Life",
    },
  },
  "Forest Animals": {
    "Woodland Creatures": {
      type: "NTM",
      department: "Forest Department",
      team: "Woodland Team",
      leader: "Nature Documentary",
    },
    "Rainforest Species": {
      type: "TM",
      department: "Tropical Department",
      team: "Rainforest Research",
      leader: "Biodiversity Study",
    },
    "Mountain Wildlife": {
      type: "NTM",
      department: "Mountain Department",
      team: "Alpine Team",
      leader: "Mountain Ecology",
    },
  },
  "Arctic Animals": {
    "Polar Bears": {
      type: "TM",
      department: "Arctic Department",
      team: "Polar Research",
      leader: "Polar Bear Study",
    },
    "Arctic Foxes": {
      type: "NTM",
      department: "Arctic Department",
      team: "Fox Team",
      leader: "Arctic Adaptation",
    },
    Penguins: {
      type: "TM",
      department: "Antarctic Department",
      team: "Penguin Colony",
      leader: "Penguin Behavior",
    },
  },
  "Desert Animals": {
    Camels: {
      type: "NTM",
      department: "Desert Department",
      team: "Camel Team",
      leader: "Desert Adaptation",
    },
    "Desert Reptiles": {
      type: "TM",
      department: "Reptile Department",
      team: "Desert Reptile",
      leader: "Reptile Research",
    },
    "Nocturnal Hunters": {
      type: "NTM",
      department: "Desert Department",
      team: "Night Team",
      leader: "Nocturnal Study",
    },
  },
  "Tropical Birds": {
    Parrots: {
      type: "TM",
      department: "Avian Department",
      team: "Parrot Team",
      leader: "Parrot Behavior",
    },
    Hummingbirds: {
      type: "NTM",
      department: "Avian Department",
      team: "Hummingbird Study",
      leader: "Flight Mechanics",
    },
    "Birds of Paradise": {
      type: "TM",
      department: "Tropical Department",
      team: "Paradise Team",
      leader: "Mating Displays",
    },
  },
  Reptiles: {
    Snakes: { type: "TM", department: "Reptile Department", team: "Snake Team", leader: "Venom Research" },
    Lizards: {
      type: "NTM",
      department: "Reptile Department",
      team: "Lizard Study",
      leader: "Thermoregulation",
    },
    Turtles: {
      type: "TM",
      department: "Marine Department",
      team: "Turtle Conservation",
      leader: "Sea Turtle Migration",
    },
  },
  "Farm Animals": {
    Cattle: {
      type: "NTM",
      department: "Agriculture Department",
      team: "Livestock Team",
      leader: "Cattle Management",
    },
    Poultry: {
      type: "TM",
      department: "Agriculture Department",
      team: "Poultry Team",
      leader: "Egg Production",
    },
    "Sheep & Goats": {
      type: "NTM",
      department: "Agriculture Department",
      team: "Small Livestock",
      leader: "Wool & Milk",
    },
  },
  Insects: {
    Butterflies: {
      type: "TM",
      department: "Entomology Department",
      team: "Butterfly Team",
      leader: "Pollination Study",
    },
    Beetles: {
      type: "NTM",
      department: "Entomology Department",
      team: "Beetle Research",
      leader: "Decomposition",
    },
    Bees: {
      type: "TM",
      department: "Entomology Department",
      team: "Bee Conservation",
      leader: "Hive Management",
    },
  },
  Primates: {
    "Great Apes": {
      type: "TM",
      department: "Primate Department",
      team: "Ape Research",
      leader: "Cognitive Studies",
    },
    Monkeys: {
      type: "NTM",
      department: "Primate Department",
      team: "Monkey Team",
      leader: "Social Behavior",
    },
    Lemurs: {
      type: "TM",
      department: "Madagascar Department",
      team: "Lemur Conservation",
      leader: "Endemic Species",
    },
  },
}

export default function ImageManagement() {
  const [ideaNiches, setIdeaNiches] = useState([
    {
      id: "001",
      folderName: "African Safari Lions Collection",
      model: "Google.Labs",
      accountSocial: "instagram",
      usernameSocial: "@wildlife_explorer",
      groupAccountSocial: "Wildlife Group",
      statusAccountSocial: "Available New", // Updated to match dropdown options
      loginAppClone: "Active", // Updated to match dropdown options
      statusContentFolder: "Start",
      statusNewSquare: "Start",
      statusReelVertical: "Start",
      statusSquareProduct: "Start",
      idea: "Wild Cats",
      niche: ["African Safari"],
      type: "NTM",
      departmentWorks: "Wildlife Department",
      groupWork: "Safari Team",
      userWorks: "Wildlife Photography",
      status: "Active",
      createdBy: "John Doe",
      updatedBy: "Jane Smith",
      createdAt: "2024-01-15",
      updatedAt: "2024-01-20",
      images: {
        subject: Array.from({ length: 15 }, (_, i) => ({
          id: `subject-${i + 1}`,
          name: `lion_${i + 1}.jpg`,
          url: `/placeholder.svg?height=200&width=200&query=lion${i + 1}`,
        })),
        scene: Array.from({ length: 8 }, (_, i) => ({
          id: `scene-${i + 1}`,
          name: `savanna_${i + 1}.jpg`,
          url: `/placeholder.svg?height=200&width=200&query=savanna${i + 1}`,
        })),
        style: Array.from({ length: 5 }, (_, i) => ({
          id: `style-${i + 1}`,
          name: `golden_hour_${i + 1}.jpg`,
          url: `/placeholder.svg?height=200&width=200&query=golden${i + 1}`,
        })),
      },
    },
    {
      id: "002",
      folderName: "Deep Sea Whale Research",
      model: "Freepik",
      accountSocial: "tiktok",
      usernameSocial: "@wildlife_tiktok",
      groupAccountSocial: "Marine Research Group",
      statusAccountSocial: "Dead", // Updated to match dropdown options
      loginAppClone: "N/A", // Updated to match dropdown options
      statusContentFolder: "Stop",
      statusNewSquare: "Stop",
      statusReelVertical: "Start",
      statusSquareProduct: "Stop",
      idea: "Ocean Mammals",
      niche: ["Deep Sea Giants"],
      type: "TM",
      departmentWorks: "Marine Department",
      groupWork: "Deep Sea Research",
      userWorks: "Marine Biology",
      status: "Locker",
      createdBy: "Mike Ocean",
      updatedBy: "Current User",
      createdAt: "2024-01-10",
      updatedAt: "2025-01-05",
    },
    {
      id: "003",
      folderName: "Tropical Parrot Paradise",
      model: "Google.Labs",
      accountSocial: "youtube",
      usernameSocial: "Wildlife Channel",
      groupAccountSocial: "Avian Team",
      statusAccountSocial: "Checkpoint", // Updated to match dropdown options
      loginAppClone: "Active", // Updated to match dropdown options
      statusContentFolder: "Start",
      statusNewSquare: "Start",
      statusReelVertical: "Start",
      statusSquareProduct: "Start",
      idea: "Tropical Birds",
      niche: ["Parrots", "Hummingbirds"],
      type: "TM",
      departmentWorks: "Avian Department",
      groupWork: "Parrot Team",
      userWorks: "Parrot Behavior",
      status: "Pending",
      createdBy: "Sarah Bird",
      updatedBy: "Current User",
      createdAt: "2024-01-12",
      updatedAt: "2025-01-03",
    },
    {
      id: "004",
      folderName: "Enchanted Woodland Creatures",
      model: "Freepik",
      accountSocial: "instagram",
      usernameSocial: "@nature_shots",
      groupAccountSocial: "Forest Team",
      statusAccountSocial: "Available New", // Updated to match dropdown options
      loginAppClone: "Dead", // Updated to match dropdown options
      statusContentFolder: "Start",
      statusNewSquare: "Stop",
      statusReelVertical: "Stop",
      statusSquareProduct: "Start",
      idea: "Forest Animals",
      niche: ["Woodland Creatures"],
      type: "NTM",
      departmentWorks: "Forest Department",
      groupWork: "Woodland Team",
      userWorks: "Nature Documentary",
      status: "Active",
      createdBy: "Forest Ranger",
      updatedBy: "Current User",
      createdAt: "2024-01-08",
      updatedAt: "2025-01-02",
    },
    {
      id: "005",
      folderName: "Majestic Polar Bear Expedition",
      model: "Google.Labs",
      accountSocial: "pinterest",
      usernameSocial: "Wildlife Boards",
      groupAccountSocial: "Polar Research",
      statusAccountSocial: "InUseDevice", // Updated to match dropdown options
      loginAppClone: "NetworkError", // Updated to match dropdown options
      statusContentFolder: "Stop",
      statusNewSquare: "Start",
      statusReelVertical: "Stop",
      statusSquareProduct: "Stop",
      idea: "Arctic Animals",
      niche: ["Polar Bears"],
      type: "TM",
      departmentWorks: "Arctic Department",
      groupWork: "Polar Research",
      userWorks: "Polar Bear Study",
      status: "Pending",
      createdBy: "Arctic Explorer",
      updatedBy: "Current User",
      createdAt: "2024-01-05",
      updatedAt: "2025-01-01",
    },
    {
      id: "006",
      folderName: "Sahara Camel Caravan",
      model: "Freepik",
      accountSocial: "medium",
      usernameSocial: "Wildlife Stories",
      groupAccountSocial: "Desert Team",
      statusAccountSocial: "Available New", // Updated to match dropdown options
      loginAppClone: "Active", // Updated to match dropdown options
      statusContentFolder: "Start",
      statusNewSquare: "Stop",
      statusReelVertical: "Start",
      statusSquareProduct: "Stop",
      idea: "Desert Animals",
      niche: ["Camels"],
      type: "NTM",
      departmentWorks: "Desert Department",
      groupWork: "Camel Team",
      userWorks: "Desert Adaptation",
      status: "Locker",
      createdBy: "Desert Guide",
      updatedBy: "Current User",
      createdAt: "2024-01-03",
      updatedAt: "2024-12-30",
    },
  ])

  // Removed unused MultiSelect component and added missing state variables
  const [activeTab, setActiveTab] = useState("instagram")
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [selectedUsernameSocial, setSelectedUsernameSocial] = useState("")
  const [selectedGroupAccountSocial, setSelectedGroupAccountSocial] = useState("")
  const [usernameSearch, setUsernameSearch] = useState("")
  const [selectedIdea, setSelectedIdea] = useState("")
  const [selectedNiche, setSelectedNiche] = useState([])
  const [autoSyncInfo, setAutoSyncInfo] = useState({ type: "", department: "", team: "", leader: "" })
  const [selectedAccountSocial, setSelectedAccountSocial] = useState("")
  const [selectedModel, setSelectedModel] = useState("")

  const [isFilterOpen, setIsFilterOpen] = useState(true)
  const [isOverviewOpen, setIsOverviewOpen] = useState(true)
  const [folderNameSearch, setFolderNameSearch] = useState("")

  // Filter presets state
  const [filterPresets, setFilterPresets] = useState([]) // Add state for filter presets
  const [viewGuideVisible, setViewGuideVisible] = useState(false) // Add state for user guide visibility in view modal

  // Pagination state (global for all platforms for now, but can be made platform-specific)
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(10) // Default items per page
  const [selectedIds, setSelectedIds] = useState([])

  // Image view states
  const [viewImagesModal, setViewImagesModal] = useState({
    isOpen: false,
    images: [],
    title: "",
    ideaNicheId: "",
    folderType: "subject",
    currentImagePage: 1,
    viewMode: "grid", // 'grid' or 'list'
    selectedImage: null,
  })

  const [uploadModal, setUploadModal] = useState({
    isOpen: false,
    ideaNicheId: "",
    folderType: "subject", // 'subject', 'scene', 'style'
    uploadProgress: 0,
    isUploading: false,
  })

  // State for folder name in create modal
  const [selectedFolderName, setSelectedFolderName] = useState("")
  const [folderStatusContent, setFolderStatusContent] = useState({})
  const [selectedStatusContent, setSelectedStatusContent] = useState("Start")

  // Edit modal state and handlers
  const [editModal, setEditModal] = useState({
    isOpen: false,
    item: null, // The item being edited
    folderName: "",
    model: "",
    accountSocial: "",
    usernameSocial: "", // Changed to string
    groupAccountSocial: "", // Added groupAccountSocial to edit modal state
    idea: "",
    niche: [],
    autoSyncInfo: { type: "", department: "", team: "", leader: "" },
    statusAccountSocial: "", // Add these fields to edit modal state
    loginAppClone: "",
  })
  const [editingItem, setEditingItem] = useState(null) // To store the item being edited
  const [isEditModalOpen, setIsEditModalOpen] = useState(false) // State to control the edit modal visibility

  // ADDED: Bulk create modal state for caption and media files
  const [bulkCreateModal, setBulkCreateModal] = useState({
    isOpen: false,
    ideaNicheId: null,
    folderType: null,
    folderName: null,
    quantity: 5,
  })

  // Content type configurations
  const [contentTypeConfigs, setContentTypeConfigs] = useState({
    new: {
      dayOfWeeks: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      timeRanges: [
        { from: "09:00", to: "11:00" },
        { from: "19:00", to: "21:00" },
      ],
    },
    reel: {
      dayOfWeeks: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      timeRanges: [
        { from: "12:00", to: "14:00" },
        { from: "21:30", to: "23:30" },
      ],
    },
    squareProduct: {
      dayOfWeeks: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      timeRanges: [
        { from: "06:00", to: "08:00" },
        { from: "15:00", to: "17:00" },
      ],
    },
  })

  const [deleteConfirmation, setDeleteConfirmation] = useState({
    isOpen: false,
    type: null,
    postId: null,
    position: null,
    postNumber: null,
  })

  const models = ["Google.Labs", "Freepik"]
  const ideas = [
    "Wild Cats",
    "Ocean Mammals",
    "Forest Animals",
    "Arctic Animals",
    "Desert Animals",
    "Tropical Birds",
    "Reptiles",
    "Farm Animals",
    "Insects",
    "Primates",
  ]
  const nichesByIdea = {
    "Wild Cats": ["African Safari", "Asian Tigers", "Mountain Lions"],
    "Ocean Mammals": ["Deep Sea Giants", "Coastal Dolphins", "Arctic Seals"],
    "Forest Animals": ["Woodland Creatures", "Rainforest Species", "Mountain Wildlife"],
    "Arctic Animals": ["Polar Bears", "Arctic Foxes", "Penguins"],
    "Desert Animals": ["Camels", "Desert Reptiles", "Nocturnal Hunters"],
    "Tropical Birds": ["Parrots", "Hummingbirds", "Birds of Paradise"],
    Reptiles: ["Snakes", "Lizards", "Turtles"],
    "Farm Animals": ["Cattle", "Poultry", "Sheep & Goats"],
    Insects: ["Butterflies", "Beetles", "Bees"],
    Primates: ["Great Apes", "Monkeys", "Lemurs"],
  }

  // Get unique values for filter dropdowns
  const getAllUniqueFilterValues = () => {
    const departments = new Set(ideaNiches.map((item) => item.departmentWorks))
    const teams = new Set(ideaNiches.map((item) => item.groupWork))
    const users = new Set(ideaNiches.map((item) => item.userWorks))
    const ideas = new Set(ideaNiches.map((item) => item.idea))
    const niches = new Set(ideaNiches.flatMap((item) => item.niche))
    const createdBy = new Set(ideaNiches.map((item) => item.createdBy))
    const updatedBy = new Set(ideaNiches.map((item) => item.updatedBy))
    const models = new Set(ideaNiches.map((item) => item.model))

    return {
      departments: Array.from(departments),
      teams: Array.from(teams),
      users: Array.from(users),
      ideas: Array.from(ideas),
      niches: Array.from(niches),
      createdBy: Array.from(createdBy),
      updatedBy: Array.from(updatedBy),
      models: Array.from(models),
    }
  }
  const allUniqueFilterValues = getAllUniqueFilterValues()

  const allNiches = Array.from(new Set(Object.values(nichesByIdea).flat()))
  const allSocialPlatforms = useMemo(() => Object.keys(socialPlatforms), [])

  // Fix for redeclaration errors
  const [createSelectedUsernameSocial, setCreateSelectedUsernameSocial] = useState("")
  const [createSelectedGroupAccountSocial, setCreateSelectedGroupAccountSocial] = useState("")

  // Updated group mock data
  const groupMockData = {
    instagram: ["Wildlife Influencers", "Nature Brands", "Eco Travelers"],
    threads: ["Science Discuss", "Nature Threads", "Eco News"],
    facebook: ["Wildlife Photography Group", "Nature Lovers Community"],
    x: ["Wild News Network", "Conservation Alerts"],
    tiktok: ["Nature Shorts Team", "Animal Clips Crew"],
    youtube: ["Doc Channel Crew", "Safari Vloggers"],
    linkedin: ["Conservation Pros", "Wildlife Scientists"],
    pinterest: ["Nature Moodboards", "Animal Art Curators"],
    medium: ["Wild Writers", "Eco Bloggers"],
    reddit: ["Subreddit Mods", "Nature Enthusiasts"],
    tumblr: ["Nature Aesthetics", "Wild Art Blogs"],
    quora: ["Wildlife Experts", "Nature Guides"],
  }

  // Declare usernamesByGroup
  const usernamesByGroup = {
    "Wildlife Influencers": ["@wildlife_explorer", "@nature_shots", "@animal_kingdom"],
    "Nature Brands": ["@wildlife_brand_1", "@nature_co", "@eco_products"],
    "Eco Travelers": ["@eco_adventurer", "@travel_nature", "@wild_journeys"],
    "Science Discuss": ["@science_hub", "@research_talk", "@knowledge_share"],
    "Nature Threads": ["@nature_stories_app", "@threads_nature", "@eco_updates"],
    "Eco News": ["@eco_news_feed", "@green_planet_news"],
    "Wildlife Photography Group": ["@wildlife_photography_community", "@nature_photo_club"],
    "Nature Lovers Community": ["@nature_lovers_united", "@passion_for_nature"],
    "Wild News Network": ["@wildlife_news_x", "@animal_updates_now"],
    "Conservation Alerts": ["@save_our_planet", "@eco_alerts_x"],
    "Nature Shorts Team": ["@nature_shorts_official", "@wildlife_clips_team"],
    "Animal Clips Crew": ["@animal_clips_daily", "@creature_features"],
    "Doc Channel Crew": ["@documentary_crew", "@nature_docs_channel"],
    "Safari Vloggers": ["@safari_vlogger_1", "@wildlife_adventures_yt"],
    "Conservation Pros": ["@conservation_experts_li", "@wildlife_professionals"],
    "Wildlife Scientists": ["@wildlife_science_lab", "@researchers_wildlife"],
    "Nature Moodboards": ["@nature_inspiration_boards", "@aesthetic_nature"],
    "Animal Art Curators": ["@animal_art_gallery", "@wildlife_artwork"],
    "Wild Writers": ["@wildlife_storytellers", "@nature_writers_connect"],
    "Eco Bloggers": ["@eco_conscious_blog", "@sustainable_living_blog"],
    "Subreddit Mods": ["r/wildlife_mods", "r/naturephotography_mods"],
    "Nature Enthusiasts": ["r/nature_lovers", "r/wildlife_fans"],
    "Nature Aesthetics": ["@nature_aesthetics_tmblr", "@serene_vibes"],
    "Wild Art Blogs": ["@wildart_gallery_tmblr", "@creative_nature"],
    "Wildlife Experts": ["@wildlife_expert_quora", "@ask_wildlife_expert"],
    "Nature Guides": ["@nature_guide_quora", "@outdoor_adventures_guide"],
  }

  const getFilteredUsernames = () => {
    if (!selectedGroupAccountSocial) return []
    const baseList = usernamesByGroup[selectedGroupAccountSocial] || []
    return baseList.filter((u) => u.toLowerCase().includes(usernameSearch.toLowerCase()))
  }

  const isUsernameTaken = (username) => {
    // NOTE: Changed from `items` to `ideaNiches` as `items` is not defined in this scope.
    // Also, comparing `usernameSocial` directly.
    return ideaNiches.some((item) => item.usernameSocial === username && item.accountSocial === activeTab)
  }

  // Get overview statistics for a platform
  const getPlatformOverview = (platform) => {
    const platformItems = ideaNiches.filter((item) => item.accountSocial === platform)

    const departments = new Set(platformItems.map((item) => item.departmentWorks))
    const teams = new Set(platformItems.map((item) => item.groupWork))
    const users = new Set(platformItems.map((item) => item.userWorks))
    const ideas = new Set(platformItems.map((item) => item.idea))
    const niches = new Set(platformItems.flatMap((item) => item.niche))
    const leaders = new Set(platformItems.map((item) => item.userWorks)) // Added for leader count
    const contentFolders = new Set(platformItems.map((item) => item.folderName)) // Added for content folder count
    const createdBy = new Set(platformItems.map((item) => item.createdBy)) // Added for createdBy count
    const typeTM = new Set(platformItems.filter((item) => item.type === "TM").map((item) => item.type))
    const typeNTM = new Set(platformItems.filter((item) => item.type === "NTM").map((item) => item.type))

    // Status counts
    const activeCount = platformItems.filter((item) => item.status === "Active").length
    const lockerCount = platformItems.filter((item) => item.status === "Locker").length
    const pendingCount = platformItems.filter((item) => item.status === "Pending").length

    // New fields for overview and filters
    const usernameAccounts = new Set(platformItems.map((item) => item.usernameSocial))
    const statusAccounts = new Set(platformItems.map((item) => item.statusAccountSocial))
    const loginAppClones = new Set(platformItems.map((item) => item.loginAppClone))
    const startContents = new Set(platformItems.map((item) => item.createdAt)) // Assuming createdAt as Start Content
    const stopContents = new Set(platformItems.map((item) => item.updatedAt)) // Assuming updatedAt as Stop Content

    // New fields for post status counts
    const postCounts = {
      draft: 0,
      Use: 0,
      Posted: 0,
      "Posting Error": 0,
    }
    platformItems.forEach((item) => {
      const key = `${item.id}-${"subject"}` // Placeholder for actual post data, assuming default subject
      const folderPosts = posts[key] || []
      folderPosts.forEach((post) => {
        if (post.status === "draft") postCounts.draft++
        if (post.status === "Use") postCounts.Use++
        if (post.status === "Posted") postCounts.Posted++
        if (post.status === "Posting Error") postCounts["Posting Error"]++
      })
    })

    // New fields for date-based counts (simplistic example, actual implementation might need more logic)
    const today = new Date().toISOString().split("T")[0]
    const thisWeek = new Date()
    thisWeek.setDate(thisWeek.getDate() - 7)
    const thisMonth = new Date()
    thisMonth.setMonth(thisMonth.getMonth() - 1)
    const thisQuarter = new Date()
    thisQuarter.setMonth(thisQuarter.getMonth() - 3)
    const thisYear = new Date()
    thisYear.setFullYear(thisYear.getFullYear() - 1)

    const newDaily = platformItems.filter((item) => item.createdAt >= today).length
    const newWeekly = platformItems.filter((item) => item.createdAt >= thisWeek.toISOString().split("T")[0]).length
    const newMonthly = platformItems.filter((item) => item.createdAt >= thisMonth.toISOString().split("T")[0]).length
    const newQuarterly = platformItems.filter(
      (item) => item.createdAt >= thisQuarter.toISOString().split("T")[0],
    ).length
    const newYearly = platformItems.filter((item) => item.createdAt >= thisYear.toISOString().split("T")[0]).length

    // New fields for content types
    const newSquare = platformItems.filter((item) => item.images?.subject?.length > 0).length
    const reelVertical = platformItems.filter((item) => item.images?.scene?.length > 0).length
    const squareProduct = platformItems.filter((item) => item.images?.style?.length > 0).length

    const newSquareStop = platformItems.filter(
      (item) => item.images?.subject?.length > 0 && item.statusNewSquare === "Stop",
    ).length
    const newSquareStart = platformItems.filter(
      (item) => item.images?.subject?.length > 0 && item.statusNewSquare === "Start",
    ).length
    const reelVerticalStop = platformItems.filter(
      (item) => item.images?.scene?.length > 0 && item.statusReelVertical === "Stop",
    ).length
    const reelVerticalStart = platformItems.filter(
      (item) => item.images?.scene?.length > 0 && item.statusReelVertical === "Start",
    ).length
    const squareProductStop = platformItems.filter(
      (item) => item.images?.style?.length > 0 && item.statusSquareProduct === "Stop",
    ).length
    const squareProductStart = platformItems.filter(
      (item) => item.images?.style?.length > 0 && item.statusSquareProduct === "Start",
    ).length

    // ADDED OVERVIEW COUNTS FOR NEW FIELDS
    const loginAppCloneActive = platformItems.filter((item) => item.loginAppClone === "Active").length
    const loginAppCloneDead = platformItems.filter((item) => item.loginAppClone === "Dead").length
    const loginAppCloneLocked = platformItems.filter((item) => item.loginAppClone === "LockedOnDevice").length
    const loginAppCloneLoginError = platformItems.filter((item) => item.loginAppClone === "LoginError").length
    const loginAppCloneNetworkError = platformItems.filter((item) => item.loginAppClone === "NetworkError").length
    const loginAppCloneSpam = platformItems.filter((item) => item.loginAppClone === "Spam").length
    const loginAppCloneErrorAppClone = platformItems.filter((item) => item.loginAppClone === "ErrorAppClone").length
    const loginAppCloneNA = platformItems.filter((item) => item.loginAppClone === "N/A").length

    const statusAccountAvailable = platformItems.filter((item) => item.statusAccountSocial === "Available New").length
    const statusAccountCheckpoint = platformItems.filter((item) => item.statusAccountSocial === "Checkpoint").length
    const statusAccountInUse = platformItems.filter((item) => item.statusAccountSocial === "InUseDevice").length
    const statusAccountLocked = platformItems.filter((item) => item.statusAccountSocial === "LockedOnDevice").length
    const statusAccountDead = platformItems.filter((item) => item.statusAccountSocial === "Dead").length
    const statusAccountNetworkError = platformItems.filter((item) => item.statusAccountSocial === "NetworkError").length
    const statusAccountSpam = platformItems.filter((item) => item.statusAccountSocial === "Spam").length
    const statusAccountNA = platformItems.filter((item) => item.statusAccountSocial === "N/A").length

    const startContentFolderStart = platformItems.filter((item) => item.statusContentFolder === "Start").length
    const startContentFolderStop = platformItems.filter((item) => item.statusContentFolder === "Stop").length

    return {
      totalDepartments: departments.size,
      totalTeams: teams.size,
      totalUsers: users.size,
      totalFolderImages: platformItems.length, // This might represent the number of folders/items
      totalIdeas: ideas.size,
      totalNiches: niches.size,
      totalActive: activeCount,
      totalLocker: lockerCount,
      totalPending: pendingCount,
      totalUsernameAccount: usernameAccounts.size,
      totalStatusAccount: statusAccounts.size,
      totalLoginAppClone: loginAppClones.size,
      totalStartContent: startContents.size, // Placeholder
      totalStopContent: stopContents.size, // Placeholder
      totalNewDaily: newDaily,
      totalNewWeekly: newWeekly,
      totalNewMonthly: newMonthly,
      totalNewQuarterly: newQuarterly,
      totalNewYearly: newYearly,
      totalDraft: postCounts.draft,
      totalUse: postCounts.Use,
      totalPosted: postCounts.Posted,
      totalError: postCounts["Posting Error"],
      totalNewSquare: newSquare,
      totalReelVertical: reelVertical,
      totalSquareProduct: squareProduct,
      newSquareStop,
      newSquareStart,
      reelVerticalStop,
      reelVerticalStart,
      squareProductStop,
      squareProductStart,
      totalLeader: leaders.size, // Added for overview
      totalContentFolder: contentFolders.size, // Added for overview
      totalCreatedBy: createdBy.size, // Added for overview
      totalTypeTM: typeTM.size, // Added for overview
      totalTypeNTM: typeNTM.size, // Added for overview
      // ADDED OVERVIEW COUNTS FOR NEW FIELDS
      loginAppCloneActive,
      loginAppCloneDead,
      loginAppCloneLocked,
      loginAppCloneLoginError,
      loginAppCloneNetworkError,
      loginAppCloneSpam,
      loginAppCloneErrorAppClone,
      loginAppCloneNA,
      statusAccountAvailable,
      statusAccountCheckpoint,
      statusAccountInUse,
      statusAccountLocked,
      statusAccountDead,
      statusAccountNetworkError,
      statusAccountSpam,
      statusAccountNA,
      startContentFolderStart,
      startContentFolderStop,
    }
  }

  // Handle status change for items
  const handleItemStatusChange = (itemId, newStatus) => {
    setIdeaNiches((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            status: newStatus,
            updatedBy: "Current User",
            updatedAt: new Date().toISOString().split("T")[0],
          }
        }
        return item
      }),
    )
  }

  const handleStatusFieldUpdate = (itemId, field, newValue) => {
    setIdeaNiches((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            [field]: newValue,
            updatedBy: "Current User",
            updatedAt: new Date().toISOString().split("T")[0],
          }
        }
        return item
      }),
    )
  }

  // Auto-sync when idea and niche are selected for create modal
  useEffect(() => {
    if (selectedIdea && selectedNiche.length > 0) {
      const syncData = autoSyncData[selectedIdea]?.[selectedNiche[0]]
      if (syncData) {
        setAutoSyncInfo(syncData)
      }
    } else {
      setAutoSyncInfo({ type: "", department: "", team: "", leader: "" })
    }
  }, [selectedIdea, selectedNiche])

  // Auto-sync for edit modal
  useEffect(() => {
    if (editModal.idea && editModal.niche.length > 0) {
      const syncData = autoSyncData[editModal.idea]?.[editModal.niche[0]]
      if (syncData) {
        setEditModal((prev) => ({
          ...prev,
          autoSyncInfo: syncData,
        }))
      }
    } else {
      setEditModal((prev) => ({
        ...prev,
        autoSyncInfo: { type: "", department: "", team: "", leader: "" },
      }))
    }
  }, [editModal.idea, editModal.niche])

  // Reset username when social platform changes in create modal
  useEffect(() => {
    if (selectedAccountSocial) {
      setCreateSelectedUsernameSocial("")
      setUsernameSearch("")
    }
  }, [selectedAccountSocial])

  // Reset username when social platform changes in edit modal
  useEffect(() => {
    if (editModal.accountSocial) {
      setEditModal((prev) => ({ ...prev, usernameSocial: "", groupAccountSocial: "" })) // Reset both username and group
    }
  }, [editModal.accountSocial])

  const handleCreateNew = () => {
    if (activeTab && selectedUsernameSocial && selectedIdea && selectedNiche.length > 0 && selectedFolderName) {
      const isTaken = isUsernameTaken(selectedUsernameSocial)

      if (isTaken) {
        alert(`Username "${selectedUsernameSocial}" already exists for ${activeTab}. Please choose another username.`)
        return
      }

      const newFolder = {
        id: String(ideaNiches.length + 1).padStart(3, "0"),
        folderName: selectedFolderName,
        accountSocial: selectedAccountSocial || activeTab,
        groupAccountSocial: selectedGroupAccountSocial, // Use the corrected state
        usernameSocial: selectedUsernameSocial,
        // Added statusAccountSocial and loginAppClone
        statusAccountSocial: "Available New", // Default to Active for new entries
        loginAppClone: "Active", // Default to App Clone 1 for new entries
        statusContentFolder: "Start",
        statusNewSquare: "Start",
        statusReelVertical: "Start",
        statusSquareProduct: "Start",
        idea: selectedIdea,
        niche: selectedNiche,
        type: autoSyncInfo.type,
        departmentWorks: autoSyncInfo.department,
        groupWork: autoSyncInfo.team,
        userWorks: autoSyncInfo.leader,
        status: "Pending", // New items start as Pending
        createdBy: "Current User",
        updatedBy: "Current User",
        createdAt: new Date().toISOString().split("T")[0],
        updatedAt: new Date().toISOString().split("T")[0],
        images: {
          subject: [],
          scene: [],
          style: [],
        },
      }
      setIdeaNiches([...ideaNiches, newFolder])
      setSelectedModel("")
      setSelectedAccountSocial("")
      setSelectedUsernameSocial("") // Reset the corrected state
      setSelectedGroupAccountSocial("") // Reset the corrected state
      setSelectedIdea("")
      setSelectedNiche([])
      setUsernameSearch("")
      setAutoSyncInfo({ type: "", department: "", team: "", leader: "" })
      setIsCreateModalOpen(false)
      setSelectedFolderName("")
    } else {
      // Optionally provide feedback to the user about missing fields
      alert("Please fill in all required fields.")
    }
  }

  const handleViewImages = (images, title, ideaNicheId, folderType) => {
    setViewImagesModal({
      isOpen: true,
      images,
      title,
      ideaNicheId,
      folderType,
      currentImagePage: 1,
      viewMode: "grid",
      selectedImage: null,
    })
  }

  const handleDeleteImage = (ideaNicheId, folderType, imageId) => {
    setIdeaNiches((prev) =>
      prev.map((item) => {
        if (item.id === ideaNicheId) {
          return {
            ...item,
            images: {
              ...item.images,
              [folderType]: item.images[folderType].filter((img) => img.id !== imageId),
            },
            updatedBy: "Current User",
            updatedAt: new Date().toISOString().split("T")[0],
          }
        }
        return item
      }),
    )
  }

  const handleOpenUpload = (ideaNicheId, folderType) => {
    setUploadModal({ isOpen: true, ideaNicheId, folderType, uploadProgress: 0, isUploading: false })
  }

  const handleUploadImages = async (files) => {
    if (!files || files.length === 0) return

    setUploadModal((prev) => ({ ...prev, isUploading: true, uploadProgress: 0 }))

    const newImages = []
    const totalFiles = files.length

    for (let i = 0; i < totalFiles; i++) {
      const file = files[i]
      // Simulate upload progress
      await new Promise((resolve) => setTimeout(resolve, 50))

      newImages.push({
        id: `${Date.now()}-${i}`,
        name: file.name,
        url: `/placeholder.svg?height=200&width=200&query=${file.name.split(".")[0]}`,
      })

      setUploadModal((prev) => ({
        ...prev,
        uploadProgress: Math.round(((i + 1) / totalFiles) * 100),
      }))
    }

    setIdeaNiches((prev) =>
      prev.map((item) => {
        if (item.id === uploadModal.ideaNicheId) {
          const updatedItem = {
            ...item,
            images: {
              ...item.images,
              [uploadModal.folderType]: [...item.images[uploadModal.folderType], ...newImages],
            },
            updatedBy: "Current User",
            updatedAt: new Date().toISOString().split("T")[0],
          }

          // Auto-change status to Active when uploading images
          if (item.status === "Pending") {
            updatedItem.status = "Active"
          }

          return updatedItem
        }
        return item
      }),
    )

    setTimeout(() => {
      setUploadModal({ isOpen: false, ideaNicheId: "", folderType: "subject", uploadProgress: 0, isUploading: false })
    }, 500)
  }

  const handleOpenEdit = (item) => {
    setEditModal({
      isOpen: true,
      item: item,
      folderName: item.folderName,
      model: item.model,
      accountSocial: item.accountSocial,
      usernameSocial: item.usernameSocial,
      groupAccountSocial: item.groupAccountSocial,
      idea: item.idea,
      niche: item.niche,
      autoSyncInfo: {
        type: item.type,
        department: item.departmentWorks,
        team: item.groupWork,
        leader: item.userWorks,
      },
      statusAccountSocial: item.statusAccountSocial, // Add these fields to editModal state
      loginAppClone: item.loginAppClone,
    })
    setEditingItem(item)
    setIsEditModalOpen(true)
  }

  const handleUpdateItem = () => {
    if (
      editModal.model &&
      editModal.accountSocial &&
      editModal.usernameSocial &&
      editModal.groupAccountSocial && // Added check for groupAccountSocial
      editModal.idea &&
      editModal.niche.length > 0 &&
      editModal.item &&
      editModal.folderName // Keep folderName as it's still being edited potentially
    ) {
      setIdeaNiches((prev) =>
        prev.map((item) => {
          if (item.id === editModal.item.id) {
            return {
              ...item,
              folderName: editModal.folderName,
              model: editModal.model,
              accountSocial: editModal.accountSocial,
              usernameSocial: editModal.usernameSocial,
              groupAccountSocial: editModal.groupAccountSocial, // Updated groupAccountSocial
              // Updated values for statusAccountSocial and loginAppClone
              statusAccountSocial: editModal.statusAccountSocial,
              loginAppClone: editModal.loginAppClone,
              idea: editModal.idea,
              niche: editModal.niche,
              type: editModal.autoSyncInfo.type,
              departmentWorks: editModal.autoSyncInfo.department,
              groupWork: editModal.autoSyncInfo.team,
              userWorks: editModal.autoSyncInfo.leader,
              updatedBy: "Current User",
              updatedAt: new Date().toISOString().split("T")[0],
            }
          }
          return item
        }),
      )
      setEditModal({
        isOpen: false,
        item: null,
        folderName: "",
        model: "",
        accountSocial: "",
        usernameSocial: "",
        groupAccountSocial: "", // Reset groupAccountSocial
        idea: "",
        niche: [],
        autoSyncInfo: { type: "", department: "", team: "", leader: "" },
        statusAccountSocial: "", // Reset these too
        loginAppClone: "",
      })
      setIsEditModalOpen(false) // Close the modal
      setEditingItem(null)
    } else {
      alert("Please fill in all required fields for editing.")
    }
  }

  // Clear filters for specific platform
  const clearPlatformFilters = (platform) => {
    setPlatformFilters((prev) => ({
      ...prev,
      [platform]: {
        model: "all",
        departmentWorks: "all",
        groupWork: "all",
        userWorks: "all",
        idea: "all",
        niche: [],
        status: "all",
        updatedBy: "all",
        // Add new fields for filters
        departments: "all",
        teams: "all",
        leader: "all",
        createdBy: "all",
        contentFolder: "all",
        niches: "all",
        usernameAccount: "all",
        statusAccount: "all",
        loginAppClone: "all",
        startContent: "all",
        stopContent: "all",
        newDaily: "all",
        newWeekly: "all",
        newMonthly: "all",
        newQuarterly: "all",
        newYearly: "all",
        newSquare: "all",
        reelVertical: "all",
        squareProduct: "all",
        totalDraft: "all",
        totalUse: "all",
        totalPosted: "all",
        totalError: "all",
        statusNewSquare: "all", // Added
        statusReelVertical: "all", // Added
        statusSquareProduct: "all", // Added
      },
    }))
  }

  // Update platform filter state
  const updatePlatformFilter = (platform, field, value) => {
    setPlatformFilters((prev) => ({
      ...prev,
      [platform]: {
        ...prev[platform],
        [field]: value,
      },
    }))
  }

  // Handle saving a filter preset
  const handleSavePreset = () => {
    const newPreset = {
      name: prompt("Enter a name for this preset:"),
      filters: { ...platformFilters[activeTab] }, // Save filters for the active tab
    }
    if (newPreset.name) {
      setFilterPresets((prev) => [...prev, newPreset])
      // Optionally save to local storage or backend
    }
  }

  // Handle loading a filter preset
  const handleLoadPreset = () => {
    const presetName = prompt(`Enter the name of the preset to load:`)
    if (!presetName) return

    const presetToLoad = filterPresets.find((p) => p.name === presetName)
    if (presetToLoad) {
      setPlatformFilters((prev) => ({
        ...prev,
        [activeTab]: { ...presetToLoad.filters },
      }))
      // Update current page and items per page to reset based on new filters
      setCurrentPage(1)
      setItemsPerPage(10)
    } else {
      alert("Preset not found.")
    }
  }

  // State for platform-specific pagination
  const [platformPagination, setPlatformPagination] = useState({})

  // Initialize platform pagination state
  useEffect(() => {
    const initialPagination = {}
    allSocialPlatforms.forEach((platform) => {
      initialPagination[platform] = { currentPage: 1, itemsPerPage: 10 }
    })
    setPlatformPagination(initialPagination)
  }, []) // Empty dependency array - only run once on mount

  // Update platform pagination state
  const handlePlatformPageChange = (platform, page) => {
    setPlatformPagination((prev) => ({ ...prev, [platform]: { ...prev[platform], currentPage: page } }))
  }

  const handlePlatformItemsPerPageChange = (platform, value) => {
    setPlatformPagination((prev) => ({
      ...prev,
      [platform]: { ...prev[platform], itemsPerPage: value, currentPage: 1 },
    }))
  }

  // Platform-specific filters state
  const [platformFilters, setPlatformFilters] = useState({})

  // Initialize platformFilters state
  useEffect(() => {
    const initialFilters = {}
    allSocialPlatforms.forEach((platform) => {
      initialFilters[platform] = {
        model: "all",
        departmentWorks: "all",
        groupWork: "all",
        userWorks: "all",
        idea: "all",
        niche: "all", // Changed from array [] to string "all"
        status: "all",
        updatedBy: "all",
        departments: "all",
        teams: "all",
        leader: "all",
        createdBy: "all",
        contentFolder: "all",
        niches: "all",
        usernameAccount: "all",
        statusAccount: "all",
        loginAppClone: "all",
        startContent: "all",
        stopContent: "all",
        newDaily: "all",
        newWeekly: "all",
        newMonthly: "all",
        newQuarterly: "all",
        newYearly: "all",
        newSquare: "all",
        reelVertical: "all",
        squareProduct: "all",
        totalDraft: "all",
        totalUse: "all",
        totalPosted: "all",
        totalError: "all",
        typeTM: "all",
        typeNTM: "all",
        statusNewSquare: "all", // Added
        statusReelVertical: "all", // Added
        statusSquareProduct: "all", // Added
      }
    })
    setPlatformFilters(initialFilters)
  }, []) // Empty dependency array - only run once on mount

  // Helper to get unique values for a specific platform's filters
  const getPlatformUniqueFilterValues = (platform) => {
    const platformItems = ideaNiches.filter((item) => item.accountSocial === platform)

    const models = new Set(platformItems.map((item) => item.model))
    const departments = new Set(platformItems.map((item) => item.departmentWorks))
    const teams = new Set(platformItems.map((item) => item.groupWork))
    const users = new Set(platformItems.map((item) => item.userWorks))
    const ideas = new Set(platformItems.map((item) => item.idea))
    const niches = new Set(platformItems.flatMap((item) => item.niche))
    const updatedBy = new Set(platformItems.map((item) => item.updatedBy))
    const leaders = new Set(platformItems.map((item) => item.userWorks)) // Assuming userWorks maps to leader
    const contentFolders = new Set(platformItems.map((item) => item.folderName))
    const createdBy = new Set(platformItems.map((item) => item.createdBy))
    const usernameAccounts = new Set(platformItems.map((item) => item.usernameSocial))
    const statusAccounts = new Set(platformItems.map((item) => item.statusAccountSocial))
    const loginAppClones = new Set(platformItems.map((item) => item.loginAppClone))
    const startContents = new Set(platformItems.map((item) => item.createdAt))
    const stopContents = new Set(platformItems.map((item) => item.updatedAt))

    // Calculate counts for specific types for filtering
    const typesTM = new Set(platformItems.filter((item) => item.type === "TM").map((item) => item.type))
    const typesNTM = new Set(platformItems.filter((item) => item.type === "NTM").map((item) => item.type))

    // Post status counts
    const postCounts = {
      draft: 0,
      Use: 0,
      Posted: 0,
      "Posting Error": 0,
    }
    platformItems.forEach((item) => {
      // This part needs to access the 'posts' state which might not be available here if 'posts' is component-level.
      // Assuming 'posts' is accessible or derived. For now, we'll count based on ideaNiches properties if applicable,
      // otherwise, these counts will be 0 unless fetched or calculated differently.
      // Since getPlatformOverview already calculates these, we reuse that logic.
    })

    // Calculate date-based counts
    const today = new Date().toISOString().split("T")[0]
    const thisWeek = new Date()
    thisWeek.setDate(thisWeek.getDate() - 7)
    const thisMonth = new Date()
    thisMonth.setMonth(thisMonth.getMonth() - 1)
    const thisQuarter = new Date()
    thisQuarter.setMonth(thisQuarter.getMonth() - 3)
    const thisYear = new Date()
    thisYear.setFullYear(thisYear.getFullYear() - 1)

    const newDaily = platformItems.filter((item) => item.createdAt >= today).length
    const newWeekly = platformItems.filter((item) => item.createdAt >= thisWeek.toISOString().split("T")[0]).length
    const newMonthly = platformItems.filter((item) => item.createdAt >= thisMonth.toISOString().split("T")[0]).length
    const newQuarterly = platformItems.filter(
      (item) => item.createdAt >= thisQuarter.toISOString().split("T")[0],
    ).length
    const newYearly = platformItems.filter((item) => item.createdAt >= thisYear.toISOString().split("T")[0]).length

    // Content type counts
    const newSquare = platformItems.filter((item) => item.images?.subject?.length > 0).length
    const reelVertical = platformItems.filter((item) => item.images?.scene?.length > 0).length
    const squareProduct = platformItems.filter((item) => item.images?.style?.length > 0).length

    return {
      models: Array.from(models),
      departments: Array.from(departments),
      teams: Array.from(teams),
      users: Array.from(users),
      ideas: Array.from(ideas),
      niches: Array.from(niches),
      updatedBy: Array.from(updatedBy),
      leaders: Array.from(leaders),
      contentFolders: Array.from(contentFolders),
      createdBy: Array.from(createdBy),
      usernameAccounts: Array.from(usernameAccounts),
      statusAccounts: Array.from(statusAccounts),
      loginAppClones: Array.from(loginAppClones),
      startContents: Array.from(startContents),
      stopContents: Array.from(stopContents),
      typesTM: Array.from(typesTM),
      typesNTM: Array.from(typesNTM),
      newDaily: [newDaily], // Count is a number, wrap in array for SelectContent compatibility
      newWeekly: [newWeekly],
      newMonthly: [newMonthly],
      newQuarterly: [newQuarterly],
      newYearly: [newYearly],
      newSquare: [newSquare],
      reelVertical: [reelVertical],
      squareProduct: [squareProduct],
      totalDraft: [postCounts.draft],
      totalUse: [postCounts.Use],
      totalPosted: [postCounts.Posted],
      totalError: [postCounts["Posting Error"]],
    }
  }

  const getFilteredItems = (platform) => {
    const currentFilters = platformFilters[platform] || {
      model: "all",
      departmentWorks: "all",
      groupWork: "all",
      userWorks: "all",
      idea: "all",
      niche: "all",
      status: "all",
      updatedBy: "all",
      departments: "all",
      teams: "all",
      leader: "all",
      createdBy: "all",
      contentFolder: "all",
      niches: "all",
      usernameAccount: "all",
      statusAccount: "all",
      loginAppClone: "all",
      startContent: "all",
      stopContent: "all",
      newDaily: "all",
      newWeekly: "all",
      newMonthly: "all",
      newQuarterly: "all",
      newYearly: "all",
      newSquare: "all",
      reelVertical: "all",
      squareProduct: "all",
      totalDraft: "all",
      totalUse: "all",
      totalPosted: "all",
      totalError: "all",
      typeTM: "all",
      typeNTM: "all",
      statusNewSquare: "all", // Added
      statusReelVertical: "all", // Added
      statusSquareProduct: "all", // Added
    }
    let filtered = ideaNiches.filter((item) => item.accountSocial === platform)

    // Apply filters
    if (currentFilters.model && currentFilters.model !== "all") {
      filtered = filtered.filter((item) => item.model === currentFilters.model)
    }
    if (currentFilters.departmentWorks && currentFilters.departmentWorks !== "all") {
      filtered = filtered.filter((item) => item.departmentWorks === currentFilters.departmentWorks)
    }
    if (currentFilters.groupWork && currentFilters.groupWork !== "all") {
      filtered = filtered.filter((item) => item.groupWork === currentFilters.groupWork)
    }
    if (currentFilters.userWorks && currentFilters.userWorks !== "all") {
      filtered = filtered.filter((item) => item.userWorks === currentFilters.userWorks)
    }
    if (currentFilters.idea && currentFilters.idea !== "all") {
      filtered = filtered.filter((item) => item.idea === currentFilters.idea)
    }
    if (currentFilters.niche && currentFilters.niche !== "all") {
      filtered = filtered.filter((item) => item.niche.includes(currentFilters.niche))
    }
    if (currentFilters.status && currentFilters.status !== "all") {
      filtered = filtered.filter((item) => item.status === currentFilters.status)
    }
    if (currentFilters.updatedBy && currentFilters.updatedBy !== "all") {
      filtered = filtered.filter((item) => item.updatedBy === currentFilters.updatedBy)
    }

    // Apply new filters
    if (currentFilters.departments && currentFilters.departments !== "all") {
      filtered = filtered.filter((item) => item.departmentWorks === currentFilters.departments)
    }
    if (currentFilters.teams && currentFilters.teams !== "all") {
      filtered = filtered.filter((item) => item.groupWork === currentFilters.teams)
    }
    if (currentFilters.leader && currentFilters.leader !== "all") {
      filtered = filtered.filter((item) => item.userWorks === currentFilters.leader)
    }
    if (currentFilters.createdBy && currentFilters.createdBy !== "all") {
      filtered = filtered.filter((item) => item.createdBy === currentFilters.createdBy)
    }
    if (currentFilters.contentFolder && currentFilters.contentFolder !== "all") {
      filtered = filtered.filter((item) => item.folderName === currentFilters.contentFolder)
    }
    if (currentFilters.niches && currentFilters.niches !== "all") {
      filtered = filtered.filter((item) => item.niche.includes(currentFilters.niches))
    }
    if (currentFilters.usernameAccount && currentFilters.usernameAccount !== "all") {
      filtered = filtered.filter((item) => item.usernameSocial === currentFilters.usernameAccount)
    }
    if (currentFilters.statusAccount && currentFilters.statusAccount !== "all") {
      filtered = filtered.filter((item) => item.statusAccountSocial === currentFilters.statusAccount)
    }
    if (currentFilters.loginAppClone && currentFilters.loginAppClone !== "all") {
      filtered = filtered.filter((item) => item.loginAppClone === currentFilters.loginAppClone)
    }
    if (currentFilters.startContent && currentFilters.startContent !== "all") {
      filtered = filtered.filter((item) => item.createdAt >= currentFilters.startContent)
    }
    if (currentFilters.stopContent && currentFilters.stopContent !== "all") {
      filtered = filtered.filter((item) => item.updatedAt <= currentFilters.stopContent)
    }

    // Filter by type TM/NTM
    if (currentFilters.typeTM && currentFilters.typeTM !== "all") {
      filtered = filtered.filter((item) => item.type === "TM")
    }
    if (currentFilters.typeNTM && currentFilters.typeNTM !== "all") {
      filtered = filtered.filter((item) => item.type === "NTM")
    }

    // Filter by new counts
    if (currentFilters.newDaily && currentFilters.newDaily !== "all") {
      const today = new Date().toISOString().split("T")[0]
      filtered = filtered.filter((item) => item.createdAt >= today)
    }
    if (currentFilters.newWeekly && currentFilters.newWeekly !== "all") {
      const thisWeek = new Date()
      thisWeek.setDate(thisWeek.getDate() - 7)
      filtered = filtered.filter((item) => item.createdAt >= thisWeek.toISOString().split("T")[0])
    }
    if (currentFilters.newMonthly && currentFilters.newMonthly !== "all") {
      const thisMonth = new Date()
      thisMonth.setMonth(thisMonth.getMonth() - 1)
      filtered = filtered.filter((item) => item.createdAt >= thisMonth.toISOString().split("T")[0])
    }
    if (currentFilters.newQuarterly && currentFilters.newQuarterly !== "all") {
      const thisQuarter = new Date()
      thisQuarter.setMonth(thisQuarter.getMonth() - 3)
      filtered = filtered.filter((item) => item.createdAt >= thisQuarter.toISOString().split("T")[0])
    }
    if (currentFilters.newYearly && currentFilters.newYearly !== "all") {
      const thisYear = new Date()
      thisYear.setFullYear(thisYear.getFullYear() - 1)
      filtered = filtered.filter((item) => item.createdAt >= thisYear.toISOString().split("T")[0])
    }

    // Filter by content types
    if (currentFilters.newSquare && currentFilters.newSquare !== "all") {
      filtered = filtered.filter((item) => item.images?.subject?.length > 0)
    }
    if (currentFilters.reelVertical && currentFilters.reelVertical !== "all") {
      filtered = filtered.filter((item) => item.images?.scene?.length > 0)
    }
    if (currentFilters.squareProduct && currentFilters.squareProduct !== "all") {
      filtered = filtered.filter((item) => item.images?.style?.length > 0)
    }

    // FILTER BY CONTENT TYPE STATUS
    if (currentFilters.statusNewSquare && currentFilters.statusNewSquare !== "all") {
      filtered = filtered.filter((item) => {
        const status = item.images?.subject?.length > 0 ? "Start" : "Stop"
        return status === currentFilters.statusNewSquare
      })
    }
    if (currentFilters.statusReelVertical && currentFilters.statusReelVertical !== "all") {
      filtered = filtered.filter((item) => {
        const status = item.images?.scene?.length > 0 ? "Start" : "Stop"
        return status === currentFilters.statusReelVertical
      })
    }
    if (currentFilters.statusSquareProduct && currentFilters.statusSquareProduct !== "all") {
      filtered = filtered.filter((item) => {
        const status = item.images?.style?.length > 0 ? "Start" : "Stop"
        return status === currentFilters.statusSquareProduct
      })
    }

    // Filter by post status counts (This part needs careful implementation if 'posts' state is not directly available or if counts are dynamic)
    // For now, we assume counts are derived from 'posts' which is handled in getPlatformOverview.
    // Direct filtering based on these counts within getFilteredItems might be complex without pre-calculated data.
    // If these are meant to filter the *number* of posts, a different approach is needed.
    // If they are meant to filter based on the presence of such posts, the logic would be:
    // if (currentFilters.totalDraft && currentFilters.totalDraft !== "all") {
    //   // Logic to check if there are any draft posts for this item
    // }

    // Apply folder name search
    if (folderNameSearch) {
      filtered = filtered.filter((item) => item.folderName.toLowerCase().includes(folderNameSearch.toLowerCase()))
    }

    return filtered
  }

  // Bulk operations
  const handleSelectAll = (checked) => {
    const currentPlatformItems = getFilteredItems(activeTab) // Get items for the active tab
    if (checked) {
      setSelectedIds(currentPlatformItems.map((item) => item.id))
    } else {
      setSelectedIds([])
    }
  }

  const handleSelectItem = (id, checked) => {
    if (checked) {
      setSelectedIds((prev) => [...prev, id])
    } else {
      setSelectedIds((prev) => prev.filter((selectedId) => selectedId !== id))
    }
  }

  const handleBulkDelete = () => {
    if (selectedIds.length === 0) return

    if (confirm(`Are you sure you want to delete ${selectedIds.length} selected items?`)) {
      setIdeaNiches((prev) => prev.filter((item) => !selectedIds.includes(item.id)))
      setSelectedIds([])
    }
  }

  // Image pagination for modal
  const imagesPerPage = 20
  const totalImagePages = Math.ceil(viewImagesModal.images.length / imagesPerPage)
  const imageStartIndex = (viewImagesModal.currentImagePage - 1) * imagesPerPage
  const imageEndIndex = imageStartIndex + imageStartIndex + imagesPerPage
  const currentImages = viewImagesModal.images.slice(imageStartIndex, imageEndIndex)

  const PaginationControls = ({
    currentPage,
    totalPages,
    onPageChange,
    totalItems,
    itemsPerPage,
    onItemsPerPageChange,
    selectedCount,
    onSelectAll,
    onDeleteSelected,
    allSelected,
  }) => (
    <div className="flex items-center justify-between border-2 border-gray-300 rounded-lg p-4 bg-gray-50/50">
      {/* Left side - Bulk actions */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Checkbox checked={allSelected} onCheckedChange={onSelectAll} />
          <span className="text-sm text-gray-600">Select All ({selectedCount} selected)</span>
        </div>

        <Button
          variant="ghost"
          size="sm"
          onClick={onDeleteSelected}
          className="text-red-600 hover:bg-transparent hover:text-red-700"
          disabled={selectedCount === 0}
        >
          <Trash2 className="h-4 w-4 mr-1" />
          Delete ({selectedCount})
        </Button>

        <span className="text-sm text-gray-600">Total: {totalItems} items</span>
      </div>

      {/* Right side - Pagination */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-600">
            {Math.min((currentPage - 1) * itemsPerPage + 1, totalItems)} -{" "}
            {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems}
          </span>
          <Select value={itemsPerPage.toString()} onValueChange={(value) => onItemsPerPageChange(Number(value))}>
            <SelectTrigger className="w-16 h-8">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="5">5</SelectItem>
              <SelectItem value="10">10</SelectItem>
              <SelectItem value="20">20</SelectItem>
              <SelectItem value="50">50</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-1">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-transparent"
            onClick={() => onPageChange(1)}
            disabled={currentPage === 1}
          >
            <ChevronsLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-transparent"
            onClick={() => onPageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm px-2">
            Page {currentPage} of {totalPages}
          </span>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-transparent"
            onClick={() => onPageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 bg-transparent"
            onClick={() => onPageChange(totalPages)}
            disabled={currentPage === totalPages}
          >
            <ChevronsRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )

  const [posts, setPosts] = useState({})

  const [createPostModal, setCreatePostModal] = useState({
    isOpen: false,
    ideaNicheId: "",
    folderType: "",
    folderName: "",
    caption: "",
    mediaFiles: [], // Each media has: {id, file, url, name, type, order}
    uploadProgress: 0,
    isUploading: false,
  })

  const [viewPostsModal, setViewPostsModal] = useState({
    isOpen: false,
    posts: [],
    folderName: "",
    ideaNicheId: "",
    folderType: "",
    selectedPostIndex: 0,
    viewMode: "grid", // "grid" or "list"
    editingPostId: null, // Track which post is being edited
    currentPage: 1,
    postsPerPage: 10,
    collapsedCaptions: {},
    collapsedMedia: {},
  })

  const getPostsCount = (ideaNicheId, folderType) => {
    const key = `${ideaNicheId}-${folderType}`
    return posts[key]?.length || 0
  }

  const handlePostMediaUpload = (e) => {
    const files = Array.from(e.target.files)

    const existingFileSignatures = createPostModal.mediaFiles.map((m) => `${m.file.name}-${m.file.size}`)

    const newFiles = files.filter((file) => {
      const signature = `${file.name}-${file.size}`
      return !existingFileSignatures.includes(signature)
    })

    if (newFiles.length < files.length) {
      const duplicateCount = files.length - newFiles.length
      alert(`${duplicateCount} duplicate file(s) detected and skipped. Each file can only be uploaded once.`)
    }

    if (newFiles.length === 0) return

    const currentMaxOrder = createPostModal.mediaFiles.length
    const mediaFiles = newFiles.map((file, index) => ({
      id: Date.now() + Math.random(),
      file,
      url: URL.createObjectURL(file),
      name: file.name, // Store file name for duplicate checking
      type: file.type.startsWith("video/") ? "video" : "image",
      order: currentMaxOrder + index + 1,
    }))

    setCreatePostModal((prev) => ({
      ...prev,
      mediaFiles: [...prev.mediaFiles, ...mediaFiles],
    }))
  }

  const handleReorderMedia = (dragIndex, dropIndex) => {
    const updatedMedia = [...createPostModal.mediaFiles]
    const [draggedItem] = updatedMedia.splice(dragIndex, 1)
    updatedMedia.splice(dropIndex, 0, draggedItem)

    // Renumber all media
    const reorderedMedia = updatedMedia.map((media, index) => ({
      ...media,
      order: index + 1,
    }))

    setCreatePostModal((prev) => ({
      ...prev,
      mediaFiles: reorderedMedia,
    }))
  }

  const handleRemovePostMedia = (mediaId) => {
    const updatedMedia = createPostModal.mediaFiles
      .filter((m) => m.id !== mediaId)
      .map((media, index) => ({ ...media, order: index + 1 })) // Renumber after removal

    setCreatePostModal((prev) => ({
      ...prev,
      mediaFiles: updatedMedia,
    }))
  }

  const formatDateTime = (isoString) => {
    if (!isoString) return "N/A"
    try {
      const date = new Date(isoString)
      if (isNaN(date.getTime())) return "Invalid Date"
      const day = String(date.getDate()).padStart(2, "0")
      const month = String(date.getMonth() + 1).padStart(2, "0")
      const year = date.getFullYear()
      const hours = String(date.getHours()).padStart(2, "0")
      const minutes = String(date.getMinutes()).padStart(2, "0")
      return `${day}/${month}/${year} ${hours}:${minutes}`
    } catch (error) {
      console.log("[v0] Error formatting date:", error)
      return "Invalid Date"
    }
  }

  const handleSavePost = () => {
    if (!createPostModal.caption.trim() || createPostModal.mediaFiles.length === 0) {
      alert("Please add caption and at least one media file")
      return
    }

    const key = `${createPostModal.ideaNicheId}-${createPostModal.folderType}`
    const currentPosts = posts[key] || []
    const postNumber = currentPosts.length + 1

    const newPost = {
      id: Date.now().toString(),
      postNumber, // Post #1, Post #2, etc.
      caption: createPostModal.caption,
      mediaFiles: createPostModal.mediaFiles.sort((a, b) => a.order - b.order), // Ensure correct order
      status: "draft", // draft | Use | Posted | Posting Error
      statusChangedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      createdBy: "Current User",
      updatedAt: new Date().toISOString().split("T")[0], // Add for consistency
    }

    setPosts((prev) => ({
      ...prev,
      [key]: [...currentPosts, newPost],
    }))

    setCreatePostModal({
      isOpen: false,
      ideaNicheId: "",
      folderType: "",
      folderName: "",
      caption: "",
      mediaFiles: [],
      uploadProgress: 0,
      isUploading: false,
    })
  }

  const handleViewPosts = (ideaNicheId, folderType, folderName) => {
    const key = `${ideaNicheId}-${folderType}`
    const folderPosts = posts[key] || []

    setViewPostsModal({
      isOpen: true,
      posts: folderPosts,
      folderName,
      ideaNicheId,
      folderType,
      selectedPostIndex: folderPosts.length > 0 ? 0 : -1, // Set to -1 if no posts
      viewMode: "grid",
      editingPostId: null,
      currentPage: 1,
      postsPerPage: 10,
      collapsedCaptions: {},
      collapsedMedia: {},
    })
  }

  const handleDeletePost = (postId) => {
    const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`
    const updatedPosts = (posts[key] || [])
      .filter((p) => p.id !== postId)
      .map((post, index) => ({ ...post, postNumber: index + 1 })) // Renumber remaining posts

    setPosts((prev) => ({
      ...prev,
      [key]: updatedPosts,
    }))

    setViewPostsModal((prev) => ({
      ...prev,
      posts: updatedPosts,
      selectedPostIndex: Math.min(prev.selectedPostIndex, updatedPosts.length - 1),
    }))
  }

  const handleReorderMediaInView = (postId, dragIndex, dropIndex) => {
    const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`
    const updatedPosts = posts[key].map((post) => {
      if (post.id === postId) {
        const updatedMedia = [...post.mediaFiles]
        const [draggedItem] = updatedMedia.splice(dragIndex, 1)
        updatedMedia.splice(dropIndex, 0, draggedItem)
        return {
          ...post,
          mediaFiles: updatedMedia.map((m, i) => ({ ...m, order: i + 1 })),
        }
      }
      return post
    })

    setPosts((prev) => ({ ...prev, [key]: updatedPosts }))
    setViewPostsModal((prev) => ({ ...prev, posts: updatedPosts }))
  }

  const handleMoveMedia = (postId, mediaIndex, direction) => {
    const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`
    const updatedPosts = posts[key].map((post) => {
      if (post.id === postId) {
        const updatedMedia = [...post.mediaFiles]
        const newIndex = direction === "up" ? mediaIndex - 1 : mediaIndex + 1
        if (newIndex >= 0 && newIndex < updatedMedia.length) {
          ;[updatedMedia[mediaIndex], updatedMedia[newIndex]] = [updatedMedia[newIndex], updatedMedia[mediaIndex]]
        }
        return {
          ...post,
          mediaFiles: updatedMedia.map((m, i) => ({ ...m, order: i + 1 })),
        }
      }
      return post
    })

    setPosts((prev) => ({ ...prev, [key]: updatedPosts }))
    setViewPostsModal((prev) => ({ ...prev, posts: updatedPosts }))
  }

  const postStatusConfig = {
    draft: { label: "Draft", color: "bg-gray-100 text-gray-700 border-gray-200" },
    Use: { label: "Use", color: "bg-blue-100 text-blue-700 border-blue-200" }, // Changed to Use
    Posted: { label: "Posted", color: "bg-green-100 text-green-700 border-green-200" }, // Changed to Posted
    "Posting Error": { label: "Posting Error", color: "bg-red-100 text-red-700 border-red-200" }, // Changed to Posting Error
  }

  const getStatusBadge = (status) => {
    return postStatusConfig[status] || postStatusConfig.draft
  }

  const getStatusCounts = (ideaNicheId, folderType) => {
    const folderPosts = posts[`${ideaNicheId}-${folderType}`] || []
    return {
      draft: folderPosts.filter((p) => p.status === "draft").length,
      Use: folderPosts.filter((p) => p.status === "Use").length, // Added count for Use
      Posted: folderPosts.filter((p) => p.status === "Posted").length, // Changed to Posted
      "Posting Error": folderPosts.filter((p) => p.status === "Posting Error").length, // Changed to Posting Error
    }
  }

  const FolderCard = ({ title, images, ideaNicheId, folderType, number }) => {
    const postsCount = getPostsCount(ideaNicheId, folderType)
    const statusCounts = getStatusCounts(ideaNicheId, folderType)

    const autoStatus = statusCounts.Use >= 1 ? "Start" : "Stop"

    return (
      <Card className="h-full">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            {number && (
              <div className="flex items-center justify-center w-5 h-5 rounded-full bg-[#1e9df1] text-white text-xs font-bold">
                {number}
              </div>
            )}
            <FolderOpen className="h-4 w-4" />
            {title}
            <span
              className={`ml-2 px-2 py-0.5 rounded text-xs font-medium ${
                autoStatus === "Start" ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
              }`}
            >
              {autoStatus}
            </span>
            <Badge variant="secondary" className="ml-auto bg-[#1e9df1] text-white">
              {postsCount} Posts
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0 space-y-2">
          <div className="flex flex-wrap gap-2 min-h-[60px]">
            {posts[`${ideaNicheId}-${folderType}`]?.slice(0, 6).map((post) => (
              <div key={post.id} className="relative group">
                <img
                  src={post.mediaFiles[0]?.url || "/placeholder.svg"}
                  alt="Post preview"
                  className="w-10 h-10 object-cover rounded border cursor-pointer hover:scale-110 transition-transform"
                  onClick={() => handleViewPosts(ideaNicheId, folderType, title)}
                />
                {post.mediaFiles.length > 1 && (
                  <div className="absolute top-0 right-0 bg-black/70 text-white text-[8px] px-1 rounded-bl">
                    {post.mediaFiles.length}
                  </div>
                )}
              </div>
            ))}
            {postsCount > 6 && (
              <div
                className="w-10 h-10 bg-gray-100 rounded border flex items-center justify-center text-xs text-gray-500 cursor-pointer hover:bg-gray-200"
                onClick={() => handleViewPosts(ideaNicheId, folderType, title)}
              >
                +{postsCount - 6}
              </div>
            )}
          </div>

          <div className="grid grid-cols-4 gap-1">
            <span className="inline-flex items-center justify-center px-1.5 py-1 bg-gray-50 rounded border border-gray-200 text-[10px] font-medium text-gray-700">
              Draft ({statusCounts.draft})
            </span>
            <span className="inline-flex items-center justify-center px-1.5 py-1 bg-blue-50 rounded border border-blue-200 text-[10px] font-medium text-blue-700">
              Use ({statusCounts.Use})
            </span>
            <span className="inline-flex items-center justify-center px-1.5 py-1 bg-green-50 rounded border border-green-200 text-[10px] font-medium text-green-700">
              Posted ({statusCounts.Posted})
            </span>
            <span className="inline-flex items-center justify-center px-1.5 py-1 bg-red-50 rounded border border-red-200 text-[10px] font-medium text-red-700">
              Error ({statusCounts["Posting Error"]})
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1">
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleViewPosts(ideaNicheId, folderType, title)}
              className="h-7 text-xs bg-[#F0F4F8] hover:bg-slate-200 text-slate-700 border-slate-300"
            >
              <Eye className="h-3 w-3 mr-1" />
              View Post All ({postsCount})
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="sm" variant="outline" className="h-7 text-xs bg-transparent">
                  <Plus className="h-3 w-3 mr-1" />
                  Add
                  <ChevronDown className="h-3 w-3 ml-1" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {/* FIX: handleOpenCreatePost is declared in the scope of ImageManagement */}
                <DropdownMenuItem onClick={() => handleOpenCreatePost(ideaNicheId, folderType, title)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Single Post
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleOpenBulkCreate(ideaNicheId, folderType, title)}>
                  <Layers className="h-4 w-4 mr-2" />
                  Bulk Create Posts
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>
    )
  }

  const renderPlatformContent = (platform) => {
    const platformItems = getFilteredItems(platform)
    const { currentPage, itemsPerPage } = platformPagination[platform] || { currentPage: 1, itemsPerPage: 10 }
    const totalPages = Math.ceil(platformItems.length / itemsPerPage)
    const currentItems = platformItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
    const currentFilters = platformFilters[platform] || {
      model: "all",
      departmentWorks: "all",
      groupWork: "all",
      userWorks: "all",
      idea: "all",
      niche: "all",
      status: "all",
      updatedBy: "all",
      departments: "all",
      teams: "all",
      leader: "all",
      createdBy: "all",
      contentFolder: "all",
      niches: "all",
      usernameAccount: "all",
      statusAccount: "all",
      loginAppClone: "all",
      startContent: "all",
      stopContent: "all",
      newDaily: "all",
      newWeekly: "all",
      newMonthly: "all",
      newQuarterly: "all",
      newYearly: "all",
      newSquare: "all",
      reelVertical: "all",
      squareProduct: "all",
      totalDraft: "all",
      totalUse: "all",
      totalPosted: "all",
      totalError: "all",
      typeTM: "all",
      typeNTM: "all",
      statusNewSquare: "all", // Added
      statusReelVertical: "all", // Added
      statusSquareProduct: "all", // Added
    }
    const overview = getPlatformOverview(platform)
    const filterValues = getPlatformUniqueFilterValues(platform)

    return (
      <div className="space-y-6">
        {/* Overview Section */}
        <Collapsible open={isOverviewOpen} onOpenChange={setIsOverviewOpen}>
          <div
            className="flex items-center justify-between bg-[#F0F4F8] rounded-lg border p-3 shadow-sm cursor-pointer hover:bg-slate-100 transition-colors"
            onClick={() => setIsOverviewOpen(!isOverviewOpen)}
          >
            <h2 className="text-lg font-semibold flex items-center gap-2 text-slate-900">Overview</h2>
            <ChevronDown
              className={`h-5 w-5 text-slate-700 transition-transform duration-200 ${isOverviewOpen ? "rotate-180" : ""}`}
            />
          </div>

          <CollapsibleContent>
            <Card className="mt-4 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Row 1: Departments, Teams, Leader, Created By, Content Folder, Ideas, Niches, Type TM, Type NTM */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-3">
                    <div className="bg-white rounded-lg p-3 border border-blue-100 shadow-sm">
                      <p className="text-xs text-gray-600">Departments</p>
                      <p className="text-lg font-bold text-blue-700">{overview.totalDepartments || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-green-100 shadow-sm">
                      <p className="text-xs text-gray-600">Teams</p>
                      <p className="text-lg font-bold text-green-700">{overview.totalTeams || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-purple-100 shadow-sm">
                      <p className="text-xs text-gray-600">Leader</p>
                      <p className="text-lg font-bold text-purple-700">{overview.totalLeader || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-indigo-100 shadow-sm">
                      <p className="text-xs text-gray-600">Created By</p>
                      <p className="text-lg font-bold text-indigo-700">{overview.totalCreatedBy || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-cyan-100 shadow-sm">
                      <p className="text-xs text-gray-600">Content Folder</p>
                      <p className="text-lg font-bold text-cyan-700">{overview.totalContentFolder || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-yellow-100 shadow-sm">
                      <p className="text-xs text-gray-600">Ideas</p>
                      <p className="text-lg font-bold text-yellow-700">{overview.totalIdeas || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-orange-100 shadow-sm">
                      <p className="text-xs text-gray-600">Niches</p>
                      <p className="text-lg font-bold text-orange-700">{overview.totalNiches || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-red-100 shadow-sm">
                      <p className="text-xs text-gray-600">Type TM</p>
                      <p className="text-lg font-bold text-red-700">{overview.totalTypeTM || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-pink-100 shadow-sm">
                      <p className="text-xs text-gray-600">Type NTM</p>
                      <p className="text-lg font-bold text-pink-700">{overview.totalTypeNTM || 0}</p>
                    </div>
                  </div>

                  {/* Row 2: UserName Account, New Daily, New Monthly */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-3 gap-3">
                    <div className="bg-white rounded-lg p-3 border border-slate-100 shadow-sm">
                      <p className="text-xs text-gray-600">UserName Account</p>
                      <p className="text-lg font-bold text-slate-700">{overview.totalUsernameAccount || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-teal-100 shadow-sm">
                      <p className="text-xs text-gray-600">New Daily</p>
                      <p className="text-lg font-bold text-teal-700">{overview.totalNewDaily || 0}</p>
                    </div>
                    <div className="bg-white rounded-lg p-3 border border-teal-100 shadow-sm">
                      <p className="text-xs text-gray-600">New Monthly</p>
                      <p className="text-lg font-bold text-teal-700">{overview.totalNewMonthly || 0}</p>
                    </div>
                  </div>

                  {/* Row 3 (previously Row 4): Status Account Social, Login App Clone, Status New (combined), Combined Status ID Posts + Start Content Folder */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {/* Status Account Social - All statuses vertically */}
                    <div className="bg-white rounded-lg p-3 border border-cyan-100 shadow-sm">
                      <p className="text-xs font-semibold text-gray-700 mb-2">Status Account Social</p>
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Available New:</p>
                          <p className="text-sm font-bold text-green-600">{overview.statusAccountAvailable || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Checkpoint:</p>
                          <p className="text-sm font-bold text-orange-600">{overview.statusAccountCheckpoint || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">InUseDevice:</p>
                          <p className="text-sm font-bold text-blue-600">{overview.statusAccountInUse || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">LockedOnDevice:</p>
                          <p className="text-sm font-bold text-red-600">{overview.statusAccountLocked || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Dead:</p>
                          <p className="text-sm font-bold text-red-600">{overview.statusAccountDead || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">NetworkError:</p>
                          <p className="text-sm font-bold text-purple-600">{overview.statusAccountNetworkError || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Spam:</p>
                          <p className="text-sm font-bold text-yellow-600">{overview.statusAccountSpam || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">N/A:</p>
                          <p className="text-sm font-bold text-gray-500">{overview.statusAccountNA || 0}</p>
                        </div>
                      </div>
                    </div>

                    {/* Login App Clone - All statuses vertically */}
                    <div className="bg-white rounded-lg p-3 border border-blue-100 shadow-sm">
                      <p className="text-xs font-semibold text-gray-700 mb-2">Login App Clone</p>
                      <div className="space-y-1">
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Active:</p>
                          <p className="text-sm font-bold text-green-600">{overview.loginAppCloneActive || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Dead:</p>
                          <p className="text-sm font-bold text-red-600">{overview.loginAppCloneDead || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">LockedOnDevice:</p>
                          <p className="text-sm font-bold text-orange-600">{overview.loginAppCloneLocked || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">LoginError:</p>
                          <p className="text-sm font-bold text-red-600">{overview.loginAppCloneLoginError || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">NetworkError:</p>
                          <p className="text-sm font-bold text-purple-600">{overview.loginAppCloneNetworkError || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">Spam:</p>
                          <p className="text-sm font-bold text-yellow-600">{overview.loginAppCloneSpam || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">ErrorAppClone:</p>
                          <p className="text-sm font-bold text-pink-600">{overview.loginAppCloneErrorAppClone || 0}</p>
                        </div>
                        <div className="flex justify-between items-center">
                          <p className="text-xs text-gray-600">N/A:</p>
                          <p className="text-sm font-bold text-gray-500">{overview.loginAppCloneNA || 0}</p>
                        </div>
                      </div>
                    </div>

                    {/* Combined Status Card for New, Reel, Square Product */}
                    <div className="bg-white rounded-lg p-3 border border-emerald-100 shadow-sm">
                      <div className="space-y-3">
                        {/* Status New (Square) */}
                        <div>
                          <p className="text-xs font-semibold text-gray-700 mb-1">Status New (Square)</p>
                          <div className="space-y-1">
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Stop:</p>
                              <p className="text-sm font-bold text-red-600">{overview.newSquareStop || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Start:</p>
                              <p className="text-sm font-bold text-green-600">{overview.newSquareStart || 0}</p>
                            </div>
                          </div>
                        </div>
                        {/* Status Reel (Vertical) */}
                        <div className="border-t pt-2">
                          <p className="text-xs font-semibold text-gray-700 mb-1">Status Reel (Vertical)</p>
                          <div className="space-y-1">
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Stop:</p>
                              <p className="text-sm font-bold text-red-600">{overview.reelVerticalStop || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Start:</p>
                              <p className="text-sm font-bold text-green-600">{overview.reelVerticalStart || 0}</p>
                            </div>
                          </div>
                        </div>
                        {/* Status Square Product */}
                        <div className="border-t pt-2">
                          <p className="text-xs font-semibold text-gray-700 mb-1">Status Square Product</p>
                          <div className="space-y-1">
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Stop:</p>
                              <p className="text-sm font-bold text-red-600">{overview.squareProductStop || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Start:</p>
                              <p className="text-sm font-bold text-green-600">{overview.squareProductStart || 0}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white rounded-lg p-3 border border-indigo-100 shadow-sm">
                      <div className="space-y-3">
                        {/* Status ID Posts */}
                        <div>
                          <p className="text-xs font-semibold text-gray-700 mb-2">Status ID Posts</p>
                          <div className="space-y-1">
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Total Draft:</p>
                              <p className="text-sm font-bold text-amber-600">{overview.totalDraft || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Total Use:</p>
                              <p className="text-sm font-bold text-blue-600">{overview.totalUse || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Total Posted:</p>
                              <p className="text-sm font-bold text-green-600">{overview.totalPosted || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Total Error:</p>
                              <p className="text-sm font-bold text-red-600">{overview.totalError || 0}</p>
                            </div>
                          </div>
                        </div>
                        {/* Start Content Folder */}
                        <div className="border-t pt-2">
                          <p className="text-xs font-semibold text-gray-700 mb-2">Start Content Folder</p>
                          <div className="space-y-1">
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Stop:</p>
                              <p className="text-sm font-bold text-red-600">{overview.totalStopContent || 0}</p>
                            </div>
                            <div className="flex justify-between items-center">
                              <p className="text-xs text-gray-600">Start:</p>
                              <p className="text-sm font-bold text-green-600">{overview.totalStartContent || 0}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </CollapsibleContent>
        </Collapsible>

        {/* Filter Section */}
        <Collapsible open={isFilterOpen} onOpenChange={setIsFilterOpen}>
          <div
            className="flex items-center justify-between bg-[#F0F4F8] rounded-lg border p-3 shadow-sm cursor-pointer hover:bg-slate-100 transition-colors"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            <h2 className="text-lg font-semibold flex items-center gap-2 text-slate-900">
              <Filter className="h-5 w-5" />
              Filter
            </h2>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation()
                  handleSavePreset()
                }}
                className="h-8 bg-[#509485] hover:bg-[#3d7266] text-white border-[#509485]"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Preset
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation()
                  handleLoadPreset()
                }}
                className="h-8 bg-[#f7b928] hover:bg-[#d99e1f] text-white border-[#f7b928]"
              >
                <FolderOpen className="h-4 w-4 mr-2" />
                Load Preset ({filterPresets.length})
              </Button>
              <ChevronDown
                className={`h-5 w-5 text-slate-700 transition-transform duration-200 ${isFilterOpen ? "rotate-180" : ""}`}
              />
            </div>
          </div>

          <CollapsibleContent>
            <Card className="mt-4">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Row 1 - Departments, Teams, Leader, Created By, Ideas, Niches, Type TM, Type NTM */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-3">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Departments</Label>
                      <Select
                        value={currentFilters.departments || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "departments", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.departments?.map((dept) => (
                            <SelectItem key={dept} value={dept}>
                              {dept}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Teams</Label>
                      <Select
                        value={currentFilters.teams || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "teams", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.teams?.map((team) => (
                            <SelectItem key={team} value={team}>
                              {team}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Leader</Label>
                      <Select
                        value={currentFilters.leader || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "leader", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.leaders?.map((leader) => (
                            <SelectItem key={leader} value={leader}>
                              {leader}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Created By</Label>
                      <Select
                        value={currentFilters.createdBy || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "createdBy", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.createdBy?.map((creator) => (
                            <SelectItem key={creator} value={creator}>
                              {creator}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Ideas</Label>
                      <Select
                        value={currentFilters.ideas || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "ideas", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.ideas?.map((idea) => (
                            <SelectItem key={idea} value={idea}>
                              {idea}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Niches</Label>
                      <Select
                        value={currentFilters.niches || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "niches", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.niches?.map((niche) => (
                            <SelectItem key={niche} value={niche}>
                              {niche}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Type TM</Label>
                      <Select
                        value={currentFilters.typeTM || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "typeTM", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.typesTM?.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Type NTM</Label>
                      <Select
                        value={currentFilters.typeNTM || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "typeNTM", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.typesNTM?.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Row 2 - UserName Account, Status Account, Login App Clone, Status Content Folder, Status New, Status Reel, Status Square Product */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">UserName Account</Label>
                      <Select
                        value={currentFilters.usernameAccount || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "usernameAccount", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          {filterValues.usernameAccounts?.map((username) => (
                            <SelectItem key={username} value={username}>
                              {username}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Status Account Social</Label>
                      <Select
                        value={currentFilters.statusAccount || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "statusAccount", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="Available New">Available New</SelectItem>
                          <SelectItem value="Checkpoint">Checkpoint</SelectItem>
                          <SelectItem value="InUseDevice">InUseDevice</SelectItem>
                          <SelectItem value="LockedOnDevice">LockedOnDevice</SelectItem>
                          <SelectItem value="Dead">Dead</SelectItem>
                          <SelectItem value="NetworkError">NetworkError</SelectItem>
                          <SelectItem value="Spam">Spam</SelectItem>
                          <SelectItem value="N/A">N/A</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Login App Clone</Label>
                      <Select
                        value={currentFilters.loginAppClone || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "loginAppClone", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="Active">Active</SelectItem>
                          <SelectItem value="Dead">Dead</SelectItem>
                          <SelectItem value="LockedOnDevice">LockedOnDevice</SelectItem>
                          <SelectItem value="LoginError">LoginError</SelectItem>
                          <SelectItem value="NetworkError">NetworkError</SelectItem>
                          <SelectItem value="Spam">Spam</SelectItem>
                          <SelectItem value="ErrorAppClone">ErrorAppClone</SelectItem>
                          <SelectItem value="N/A">N/A</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Status Content Folder</Label>
                      <Select
                        value={currentFilters.statusContentFolder || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "statusContentFolder", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="Start">Start</SelectItem>
                          <SelectItem value="Stop">Stop</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* CHANGE: Added 3 new status filters for content types */}
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Status New (Square)</Label>
                      <Select
                        value={currentFilters.statusNewSquare || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "statusNewSquare", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="Start">Start</SelectItem>
                          <SelectItem value="Stop">Stop</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Status Reel (Vertical)</Label>
                      <Select
                        value={currentFilters.statusReelVertical || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "statusReelVertical", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="Start">Start</SelectItem>
                          <SelectItem value="Stop">Stop</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Status Square Product</Label>
                      <Select
                        value={currentFilters.statusSquareProduct || "all"}
                        onValueChange={(value) => updatePlatformFilter(platform, "statusSquareProduct", value)}
                      >
                        <SelectTrigger className="w-full h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All</SelectItem>
                          <SelectItem value="Start">Start</SelectItem>
                          <SelectItem value="Stop">Stop</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </CollapsibleContent>
        </Collapsible>

        <div className="flex items-center justify-between">
          <Button
            onClick={() => {
              // Set selectedAccountSocial to the current platform tab, or leave it if it's 'all'
              setSelectedAccountSocial(platform === "all" ? "" : platform)
              setCreateSelectedGroupAccountSocial("") // Reset group on new creation
              setSelectedUsernameSocial("")
              setSelectedFolderName("")
              setIsCreateModalOpen(true)
            }}
            className="bg-[#509485] hover:bg-[#3e7d71]"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create New for {platformConfig[platform]?.name || "All Platforms"}
          </Button>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search folder name..."
                value={folderNameSearch}
                onChange={(e) => setFolderNameSearch(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button variant="outline" size="sm" className="bg-[#F0F4F8] text-gray-700 border-gray-300">
              Search
            </Button>
          </div>
        </div>

        {platformItems.length === 0 ? (
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                <PaginationControls
                  totalPages={1}
                  currentPage={1}
                  itemsPerPage={10}
                  totalItems={0}
                  onPageChange={() => {}}
                  onItemsPerPageChange={() => {}}
                />

                <div className="flex items-center justify-between py-3 border-y">
                  <div className="flex items-center gap-4">
                    <Checkbox checked={false} disabled className="border-gray-300" />
                    <span className="text-sm text-gray-600">Select All (0 selected)</span>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-red-600 bg-transparent border-transparent hover:bg-transparent"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                  <span className="text-sm text-gray-600">Total: 0 items</span>
                </div>

                <div className="flex flex-col items-center justify-center py-20">
                  <div
                    className={`w-24 h-24 ${platformConfig[platform]?.bgColor} rounded-lg flex items-center justify-center mb-4`}
                  >
                    <div className="text-4xl">{platformConfig[platform]?.icon}</div>
                  </div>
                  <p className="text-gray-500 text-center">
                    No Works Folder Images yet for {platformConfig[platform]?.name}.
                    <br />
                    Press the "Create New" button to get started.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <PaginationControls
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    totalItems={platformItems.length}
                    itemsPerPage={itemsPerPage}
                    onItemsPerPageChange={(value) => {
                      setItemsPerPage(value)
                      setCurrentPage(1)
                    }}
                    selectedCount={selectedIds.length}
                    onSelectAll={handleSelectAll}
                    onDeleteSelected={handleBulkDelete}
                    allSelected={selectedIds.length === currentItems.length && currentItems.length > 0}
                  />

                  <div className="space-y-3">
                    {currentItems.map((item) => (
                      <Card
                        key={item.id}
                        className={`transition-all ${selectedIds.includes(item.id) ? "ring-2 ring-blue-500" : ""}`}
                      >
                        {/* <CardHeader className={`${platformConfig[platform]?.bgColor} border-b py-4`}> */}
                        <CardHeader className={`${platformConfig[platform]?.bgColor} border-b py-4`}>
                          {/* Row 1: No. + Folder Name + Idea/Niche/Type + Created/Updated + Edit */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3 flex-wrap">
                              <Checkbox
                                checked={selectedIds.includes(item.id)}
                                onCheckedChange={(checked) => handleSelectItem(item.id, checked)}
                              />

                              <Badge variant="secondary" className="bg-[#509485] text-white hover:bg-[#3e7d71]">
                                No. {item.id}
                              </Badge>

                              <div className="flex items-center gap-2">
                                <div
                                  className="bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-md border border-gray-200 shadow-sm hover:bg-white hover:shadow-md transition-all duration-200"
                                  title={item.folderName}
                                >
                                  <span className="text-sm text-gray-700 font-medium">{item.folderName}</span>
                                </div>

                                <span className="text-xs text-gray-600 font-medium">Idea:</span>
                                <span className="text-sm font-medium text-blue-600">{item.idea}</span>

                                <span className="text-xs text-gray-600 font-medium">Niche:</span>
                                {item.niche.map((niche, index) => (
                                  <span key={index} className="text-sm font-medium text-blue-700">
                                    {niche}
                                  </span>
                                ))}

                                <span className="text-xs text-gray-600 font-medium">Type:</span>
                                <span
                                  className={`text-sm font-semibold ${item.type === "TM" ? "text-red-600" : "text-blue-600"}`}
                                >
                                  {item.type}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-3 ml-4 flex-shrink-0">
                              <div className="flex items-center gap-2">
                                <User className="h-4 w-4 text-blue-600" />
                                <span className="text-xs text-gray-700">
                                  <span className="font-medium">Created:</span> {item.createdBy} ({item.createdAt})
                                </span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Calendar className="h-4 w-4 text-green-600" />
                                <span className="text-xs text-gray-700">
                                  <span className="font-medium">Updated:</span> {item.updatedBy} ({item.updatedAt})
                                </span>
                              </div>
                              <div className="flex items-center gap-3 ml-4 flex-shrink-0">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    const newStatus = item.statusContentFolder === "Start" ? "Stop" : "Start"
                                    handleStatusFieldUpdate(item.id, "statusContentFolder", newStatus)
                                  }}
                                  className={`flex items-center gap-1 ${
                                    item.statusContentFolder === "Stop"
                                      ? "bg-red-50 text-red-600 hover:bg-red-100 border-red-300"
                                      : "bg-green-50 text-green-600 hover:bg-green-100 border-green-300"
                                  }`}
                                >
                                  {item.statusContentFolder === "Stop" ? (
                                    <StopCircle className="h-4 w-4" />
                                  ) : (
                                    <PlayCircle className="h-4 w-4" />
                                  )}
                                  {item.statusContentFolder}
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setEditingItem(item)
                                    setIsEditModalOpen(true)
                                    handleOpenEdit(item)
                                  }}
                                  className="flex items-center gap-1"
                                >
                                  <Pencil className="h-4 w-4" />
                                  Edit
                                </Button>
                              </div>
                            </div>
                          </div>

                          {/* Row 2: Username info (LEFT) + Department/Team/Leader (RIGHT) */}
                          <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-200">
                            {/* Left side: Username + Status + Login */}
                            <div className="flex gap-2 flex-wrap items-center">
                              <span className="text-sm text-gray-600">username account:</span>
                              <span className="text-sm font-medium text-purple-700">
                                {item.usernameSocial.startsWith("@") || item.usernameSocial.startsWith("r/")
                                  ? item.usernameSocial
                                  : `@${item.usernameSocial}`}
                              </span>
                              <span className="text-sm text-gray-600">| Status Account Social:</span>
                              <Select
                                value={item.statusAccountSocial}
                                onValueChange={(value) =>
                                  handleStatusFieldUpdate(item.id, "statusAccountSocial", value)
                                }
                              >
                                <SelectTrigger className="w-[150px] h-7 border-0 bg-transparent">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Available New">
                                    <span className="text-green-600 font-medium">Available New</span>
                                  </SelectItem>
                                  <SelectItem value="Checkpoint">
                                    <span className="text-orange-600 font-medium">Checkpoint</span>
                                  </SelectItem>
                                  <SelectItem value="InUseDevice">
                                    <span className="text-blue-600 font-medium">InUseDevice</span>
                                  </SelectItem>
                                  <SelectItem value="LockedOnDevice">
                                    <span className="text-red-600 font-medium">LockedOnDevice</span>
                                  </SelectItem>
                                  <SelectItem value="Dead">
                                    <span className="text-gray-600 font-medium">Dead</span>
                                  </SelectItem>
                                  <SelectItem value="NetworkError">
                                    <span className="text-purple-600 font-medium">NetworkError</span>
                                  </SelectItem>
                                  <SelectItem value="Spam">
                                    <span className="text-yellow-600 font-medium">Spam</span>
                                  </SelectItem>
                                  <SelectItem value="N/A">
                                    <span className="text-slate-600 font-medium">N/A</span>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                              <span className="text-sm text-gray-600">| Login App Clone:</span>
                              <Select
                                value={item.loginAppClone}
                                onValueChange={(value) => handleStatusFieldUpdate(item.id, "loginAppClone", value)}
                              >
                                <SelectTrigger className="w-[150px] h-7 border-0 bg-transparent">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Active">
                                    <span className="text-green-600 font-medium">Active</span>
                                  </SelectItem>
                                  <SelectItem value="Dead">
                                    <span className="text-red-600 font-medium">Dead</span>
                                  </SelectItem>
                                  <SelectItem value="LockedOnDevice">
                                    <span className="text-orange-600 font-medium">LockedOnDevice</span>
                                  </SelectItem>
                                  <SelectItem value="LoginError">
                                    <span className="text-pink-600 font-medium">LoginError</span>
                                  </SelectItem>
                                  <SelectItem value="NetworkError">
                                    <span className="text-purple-600 font-medium">NetworkError</span>
                                  </SelectItem>
                                  <SelectItem value="Spam">
                                    <span className="text-yellow-600 font-medium">Spam</span>
                                  </SelectItem>
                                  <SelectItem value="ErrorAppClone">
                                    <span className="text-rose-600 font-medium">ErrorAppClone</span>
                                  </SelectItem>
                                  <SelectItem value="N/A">
                                    <span className="text-slate-600 font-medium">N/A</span>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </div>

                            {/* Right side: Department/Team/Leader */}
                            <div className="flex gap-2 flex-wrap items-center ml-4 flex-shrink-0">
                              <span className="text-sm text-gray-600 font-medium">Department:</span>
                              <span className="text-sm font-medium text-orange-700">{item.departmentWorks}</span>
                              <span className="text-sm text-gray-600 font-medium">Team:</span>
                              <span className="text-sm font-medium text-blue-700">{item.groupWork}</span>
                              <span className="text-sm text-gray-600 font-medium">Leader:</span>
                              <span className="text-sm font-medium text-green-700">{item.userWorks}</span>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent className="p-6">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <FolderCard
                              number={1}
                              title="New (Square)"
                              images={item.images?.subject || []}
                              ideaNicheId={item.id}
                              folderType="subject"
                            />
                            <FolderCard
                              number={2}
                              title="Reel (Vertical)"
                              images={item.images?.scene || []}
                              ideaNicheId={item.id}
                              folderType="scene"
                            />
                            <FolderCard
                              number={3}
                              title="Square Product"
                              images={item.images?.style || []}
                              ideaNicheId={item.id}
                              folderType="style"
                            />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  <PaginationControls
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={setCurrentPage}
                    totalItems={platformItems.length}
                    itemsPerPage={itemsPerPage}
                    onItemsPerPageChange={(value) => {
                      setItemsPerPage(value)
                      setCurrentPage(1)
                    }}
                    selectedCount={selectedIds.length}
                    onSelectAll={handleSelectAll}
                    onDeleteSelected={handleBulkDelete}
                    allSelected={selectedIds.length === currentItems.length && currentItems.length > 0}
                  />
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    )
  }

  // Placeholder for platformStats - this needs to be calculated based on ideaNiches
  const platformStats = allSocialPlatforms.reduce((acc, platform) => {
    acc[platform] = ideaNiches.filter((item) => item.accountSocial === platform).length
    return acc
  }, {})

  const formatCount = (count) => {
    if (count >= 1000000) {
      return (count / 1000000).toFixed(1).replace(/\.0$/, "") + "M"
    }
    if (count >= 1000) {
      return (count / 1000).toFixed(1).replace(/\.0$/, "") + "K"
    }
    return count.toString()
  }

  // Moved the selectedPost and handleStatusChange related to post status
  const [selectedPost, setSelectedPost] = useState(null)

  const [selectedPostIds, setSelectedPostIds] = useState([])

  const [statusFilter, setStatusFilter] = useState("all")

  const handlePostStatusChangeForView = (postId, newStatus) => {
    const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`
    setPosts((prev) => ({
      ...prev,
      [key]: prev[key].map((post) =>
        post.id === postId ? { ...post, status: newStatus, statusChangedAt: new Date().toISOString() } : post,
      ),
    }))

    // Update viewPostsModal to reflect changes
    setViewPostsModal((prev) => ({
      ...prev,
      posts: prev.posts.map((post) =>
        post.id === postId ? { ...post, status: newStatus, statusChangedAt: new Date().toISOString() } : post,
      ),
    }))

    // Update the selectedPost if it's the one being changed
    if (selectedPost && selectedPost.id === postId) {
      setSelectedPost((prev) => ({ ...prev, status: newStatus, statusChangedAt: new Date().toISOString() }))
    }
  }

  const getFilteredPosts = () => {
    if (statusFilter === "all") {
      return viewPostsModal.posts
    }
    // Ensure comparison is case-insensitive for statusFilter and post.status
    return viewPostsModal.posts.filter((post) => {
      const postStatus = post.status?.toLowerCase() || "draft"
      return postStatus === statusFilter.toLowerCase()
    })
  }

  const handleBulkStatusEdit = (newStatus) => {
    selectedPostIds.forEach((postId) => {
      handlePostStatusChangeForView(postId, newStatus)
    })
    setSelectedPostIds([]) // Clear selection after bulk action
  }

  // Helper to toggle caption collapse in viewPostsModal
  const toggleCaptionCollapse = (postId) => {
    setViewPostsModal((prev) => ({
      ...prev,
      collapsedCaptions: {
        ...prev.collapsedCaptions,
        [postId]: !prev.collapsedCaptions[postId],
      },
    }))
  }

  // Helper to toggle media collapse in viewPostsModal
  const toggleMediaCollapse = (postId) => {
    setViewPostsModal((prev) => ({
      ...prev,
      collapsedMedia: {
        ...prev.collapsedMedia,
        [postId]: !prev.collapsedMedia[postId],
      },
    }))
  }

  // New state for caption and media collapse
  const [isCaptionCollapsed, setIsCaptionCollapsed] = useState(false)
  const [isMediaCollapsed, setIsMediaCollapsed] = useState(false) // Changed default to false for initial view

  // Status info getter for post header
  const getStatusInfo = (status) => {
    switch (status?.toLowerCase()) {
      case "use":
        return { label: "Use", color: "bg-blue-100 text-blue-700 border-blue-200" }
      case "draft":
        return { label: "Draft", color: "bg-yellow-100 text-yellow-700 border-yellow-200" }
      case "posted":
        return { label: "Posted", color: "bg-green-100 text-green-700 border-green-200" }
      case "posting error":
        return { label: "Posting Error", color: "bg-red-100 text-red-700 border-red-200" }
      default:
        return { label: "Draft", color: "bg-yellow-100 text-yellow-700 border-yellow-200" }
    }
  }

  // Helper functions for content type scheduling configurations
  const toggleDayOfWeek = (type, day) => {
    setContentTypeConfigs((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        dayOfWeeks: prev[type].dayOfWeeks.includes(day)
          ? prev[type].dayOfWeeks.filter((d) => d !== day)
          : [...prev[type].dayOfWeeks, day],
      },
    }))
  }

  const addTimeRange = (type) => {
    setContentTypeConfigs((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        timeRanges: [...prev[type].timeRanges, { from: "09:00", to: "12:00" }],
      },
    }))
  }

  const removeTimeRange = (type, index) => {
    setContentTypeConfigs((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        timeRanges: prev[type].timeRanges.filter((_, i) => i !== index),
      },
    }))
  }

  const updateTimeRange = (type, index, field, value) => {
    setContentTypeConfigs((prev) => ({
      ...prev,
      [type]: {
        ...prev[type],
        timeRanges: prev[type].timeRanges.map((range, i) => (i === index ? { ...range, [field]: value } : range)),
      },
    }))
  }

  // Bulk create posts handler (added as per lint error)
  const handleBulkCreatePosts = () => {
    if (
      bulkCreateModal.ideaNicheId &&
      bulkCreateModal.folderType &&
      bulkCreateModal.folderName &&
      bulkCreateModal.quantity > 0
    ) {
      const key = `${bulkCreateModal.ideaNicheId}-${bulkCreateModal.folderType}`
      const currentPosts = posts[key] || []
      const newPosts = Array.from({ length: bulkCreateModal.quantity }, (_, i) => {
        const postNumber = currentPosts.length + i + 1
        return {
          id: Date.now().toString() + i,
          postNumber,
          caption: `Draft ${postNumber}`, // Auto-generate unique caption for each post
          mediaFiles: [], // Empty media files for each post
          status: "draft",
          statusChangedAt: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          createdBy: "Current User",
          updatedAt: new Date().toISOString().split("T")[0], // Add for consistency
        }
      })

      setPosts((prev) => ({
        ...prev,
        [key]: [...currentPosts, ...newPosts],
      }))

      // Update viewPostsModal to reflect the new posts if it's open for the same folder
      if (
        viewPostsModal.isOpen &&
        viewPostsModal.ideaNicheId === bulkCreateModal.ideaNicheId &&
        viewPostsModal.folderType === bulkCreateModal.folderType
      ) {
        setViewPostsModal((prev) => ({
          ...prev,
          posts: [...prev.posts, ...newPosts],
        }))
      }

      setBulkCreateModal({
        isOpen: false,
        ideaNicheId: null,
        folderType: null,
        folderName: null,
        quantity: 5,
      })
    }
  }

  // State for showing all media files in the post detail view
  const [showAllMedia, setShowAllMedia] = useState({})

  // ADDED: Handler to open Bulk Create modal
  const handleOpenBulkCreate = (ideaNicheId, folderType, folderName) => {
    setBulkCreateModal({
      isOpen: true,
      ideaNicheId,
      folderType,
      folderName,
      quantity: 5,
    })
  }

  // FIX: Declare handleOpenCreatePost as it was undeclared.
  // This function seems to be intended to open the main create modal.
  // Assuming it should be the same as setIsCreateModalOpen(true)
  const handleOpenCreatePost = (ideaNicheId, folderType, folderName) => {
    setCreatePostModal({
      isOpen: true,
      ideaNicheId,
      folderType,
      folderName,
      caption: "",
      mediaFiles: [],
      uploadProgress: 0,
      isUploading: false,
    })
  }

  // FIX: Declare handleViewMediaUpload as it was undeclared.
  // This function should handle uploading media files to an existing post in the view modal.
  const handleViewMediaUpload = (postId, e) => {
    const files = Array.from(e.target.files)
    const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`

    // Find the post to update
    const postIndex = viewPostsModal.posts.findIndex((p) => p.id === postId)
    if (postIndex === -1) return

    const currentPost = viewPostsModal.posts[postIndex]
    const existingFileSignatures = currentPost.mediaFiles.map(
      (m) => `${m.file ? m.file.name + "-" + m.file.size : m.name + "-" + m.id}`,
    ) // Include ID for existing URLs

    const newFiles = files.filter((file) => {
      const signature = `${file.name}-${file.size}`
      return !existingFileSignatures.includes(signature)
    })

    if (newFiles.length < files.length) {
      const duplicateCount = files.length - newFiles.length
      alert(`${duplicateCount} duplicate file(s) detected and skipped. Each file can only be uploaded once.`)
    }

    if (newFiles.length === 0) return

    const currentMediaCount = currentPost.mediaFiles.length
    const mediaFilesToAdd = newFiles.map((file, index) => ({
      id: Date.now() + Math.random(),
      file, // Keep the file object for upload
      url: URL.createObjectURL(file), // Temporary URL for preview
      name: file.name,
      type: file.type.startsWith("video/") ? "video" : "image",
      order: currentMediaCount + index + 1,
    }))

    const updatedPosts = viewPostsModal.posts.map((p, idx) => {
      if (idx === postIndex) {
        return {
          ...p,
          mediaFiles: [...p.mediaFiles, ...mediaFilesToAdd].sort((a, b) => a.order - b.order),
        }
      }
      return p
    })

    setPosts((prev) => ({
      ...prev,
      [key]: updatedPosts,
    }))

    setViewPostsModal((prev) => ({
      ...prev,
      posts: updatedPosts,
    }))
  }

  useEffect(() => {
    console.log("[v0] isCreateModalOpen:", isCreateModalOpen)
  }, [isCreateModalOpen])

  useEffect(() => {
    console.log("[v0] createPostModal.isOpen:", createPostModal.isOpen)
  }, [createPostModal.isOpen])

  useEffect(() => {
    console.log("[v0] viewPostsModal.isOpen:", viewPostsModal.isOpen)
  }, [viewPostsModal.isOpen])

  useEffect(() => {
    console.log("[v0] bulkCreateModal.isOpen:", bulkCreateModal.isOpen)
  }, [bulkCreateModal.isOpen])

  useEffect(() => {
    console.log("[v0] isEditModalOpen:", isEditModalOpen)
  }, [isEditModalOpen])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-sm">
              <FileText className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-semibold text-slate-900">Manual Content Social</h1>
          </div>
          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
            <div className="w-4 h-4 bg-green-500 rounded-full"></div>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="p-6">
        {/* <div className="bg-white rounded-2xl border border-gray-200 p-4 mb-6 shadow-sm">
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-3">
            {allSocialPlatforms.map((platform) => {
              const isActive = activeTab === platform
              const count = platformStats[platform] || 0

              return (
                <button
                  key={platform}
                  onClick={() => setActiveTab(platform)}
                  className={`flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all duration-200 ${
                    isActive
                      ? "bg-purple-50 border-purple-200 shadow-sm"
                      : "bg-white border-gray-200 hover:border-gray-300 hover:shadow-sm"
                  }`}
                >
                  <div className={`text-3xl ${isActive ? "scale-110" : ""} transition-transform`}>
                    {socialPlatforms[platform]?.icon}
                  </div>
                  <span className="text-xs font-medium text-gray-700 text-center">
                    {socialPlatforms[platform]?.name}
                  </span>
                  <div className="bg-black text-white text-xs font-semibold rounded-full w-6 h-6 flex items-center justify-center">
                    {count}
                  </div>
                </button>
              )
            })}
          </div>
        </div> */}

        {/* Social Platform Cards */}
        <div className="w-full mb-8">
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm mb-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-12 gap-3">
              {allSocialPlatforms.map((platform) => (
                <button
                  key={platform}
                  onClick={() => setActiveTab(platform)}
                  className={`flex flex-col items-center gap-2 px-3 py-3 rounded-xl border-2 transition-all duration-200 ${
                    activeTab === platform
                      ? "bg-blue-50 border-blue-500 shadow-md"
                      : "bg-white border-slate-200 hover:bg-blue-50 hover:border-blue-300"
                  }`}
                >
                  <span className="text-3xl">{socialPlatforms[platform]?.icon}</span>
                  <span
                    className={`text-xs font-semibold text-center ${
                      activeTab === platform ? "text-slate-900" : "text-slate-700"
                    }`}
                  >
                    {socialPlatforms[platform]?.name}
                  </span>
                  <div
                    className={`rounded-full w-6 h-6 flex items-center justify-center text-xs font-semibold ${
                      activeTab === platform ? "bg-blue-600 text-white" : "bg-slate-900 text-white"
                    }`}
                  >
                    {formatCount(platformStats[platform] || 0)}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Content for selected platform */}
          {allSocialPlatforms.map(
            (platform) => activeTab === platform && <div key={platform}>{renderPlatformContent(platform)}</div>,
          )}
        </div>

        {/* Old Tabs component removed, replaced by the card-based design above */}
        {/* <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full mb-8 bg-white border-2 border-gray-400 rounded-xl p-3 flex gap-4 overflow-x-auto shadow-sm">
            {allSocialPlatforms.map((platform) => (
              <TabsTrigger
                key={platform}
                value={platform}
                className="capitalize text-xs font-medium px-3 py-2 rounded-lg transition-all duration-200 hover:bg-gray-100 data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 flex items-center justify-center gap-1 whitespace-nowrap flex-shrink-0 border-2 border-gray-300"
              >
                <span className="text-lg">{socialPlatforms[platform]?.icon}</span>
                <span className="hidden sm:inline text-center">{socialPlatforms[platform]?.name}</span>
                <Badge
                  variant="secondary"
                  className="ml-1 h-5 min-w-[20px] px-1.5 flex items-center justify-center text-xs bg-[#91bfb4] text-white"
                >
                  {formatCount(platformStats[platform] || 0)}
                </Badge>
              </TabsTrigger>
            ))}
          </TabsList>

          {allSocialPlatforms.map((platform) => (
            <TabsContent key={platform} value={platform}>
              {renderPlatformContent(platform)}
            </TabsContent>
          ))}
        </Tabs> */}
      </div>{" "}
      {/* Close p-6 div BEFORE dialogs to prevent stacking context issues */}
      {/* ALL DIALOGS MOVED OUTSIDE p-6 CONTAINER FOR PROPER Z-INDEX STACKING */}
      {/* Create Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="max-w-7xl max-h-[90vh] p-0 overflow-hidden flex flex-col z-50">
          <DialogHeader className="p-6 border-b shrink-0 sticky top-0 bg-white z-20">
            <DialogTitle className="text-xl">Create Folder Content Manual</DialogTitle>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Step 1: Social Platform Selection */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="h-5 w-5 rounded-full p-0 flex items-center justify-center bg-[#1e9df1] text-white border-[#1e9df1]"
                >
                  1
                </Badge>
                Select Social Platform
              </h3>

              <div className="flex gap-4">
                <div className="space-y-2 w-[25%] min-w-0">
                  <Label htmlFor="social-platform" className="text-sm">
                    Social Platform
                  </Label>
                  <div className="relative">
                    <Select value={activeTab} disabled>
                      <SelectTrigger id="social-platform" className="w-full bg-gray-50 cursor-not-allowed">
                        <SelectValue placeholder="Select platform" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.keys(socialPlatforms).map((platform) => (
                          <SelectItem key={platform} value={platform} className="capitalize">
                            {platform}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Lock className="absolute right-8 top-2.5 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div className="space-y-2 w-[25%] min-w-0">
                  <Label htmlFor="status-content" className="text-sm">
                    Status Content
                  </Label>
                  <Select value={selectedStatusContent} onValueChange={setSelectedStatusContent}>
                    <SelectTrigger id="status-content">
                      <SelectValue placeholder="Select Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Start">
                        <span className="text-green-600 font-medium">Start</span>
                      </SelectItem>
                      <SelectItem value="Stop">
                        <span className="text-red-600 font-medium">Stop</span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 w-[50%] min-w-0">
                  <Label htmlFor="group-account" className="text-sm truncate block">
                    Group Account Social
                  </Label>
                  <Select onValueChange={setSelectedGroupAccountSocial} value={selectedGroupAccountSocial}>
                    <SelectTrigger id="group-account" className="w-full">
                      <SelectValue placeholder="Select Group To Show Username List" />
                    </SelectTrigger>
                    <SelectContent>
                      {(groupMockData[activeTab] || []).map((group) => (
                        <SelectItem key={group} value={group}>
                          {group}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username-social">
                  Username Social*{" "}
                  <span className="text-gray-600 font-normal">
                    (Chọn 1 Account Social Duy Nhất - Tự Động Loại Bỏ Trùng Lặp)
                  </span>
                </Label>

                {selectedGroupAccountSocial ? (
                  <div className="border rounded-lg overflow-hidden flex flex-col max-h-[300px]">
                    <div className="p-2 bg-gray-50 border-b flex items-center gap-2 shrink-0">
                      <Search className="h-4 w-4 text-gray-400" />
                      <input
                        className="bg-transparent text-sm outline-none flex-1"
                        placeholder="Search username..."
                        value={usernameSearch}
                        onChange={(e) => setUsernameSearch(e.target.value)}
                      />
                    </div>
                    <div className="overflow-y-auto flex-1">
                      <table className="w-full text-sm">
                        <thead className="bg-gray-50 sticky top-0 z-10">
                          <tr>
                            <th className="text-left p-2 font-medium text-gray-700 w-10 text-center">Select</th>
                            <th className="text-left p-2 font-medium text-gray-700">Username</th>
                            <th className="text-left p-2 font-medium text-gray-700">In Use & Not Use</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y">
                          {getFilteredUsernames().map((username) => {
                            const taken = isUsernameTaken(username)
                            return (
                              <tr
                                key={username}
                                className={`hover:bg-gray-50 cursor-pointer ${taken ? "opacity-50 cursor-not-allowed bg-gray-50" : selectedUsernameSocial === username ? "bg-blue-50" : ""}`}
                                onClick={() => {
                                  if (!taken) {
                                    setSelectedUsernameSocial(username)
                                    setSelectedFolderName(username)
                                  }
                                }}
                              >
                                <td className="p-2 flex justify-center">
                                  <div
                                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedUsernameSocial === username ? "bg-blue-600 border-blue-600" : "border-gray-300"}`}
                                  >
                                    {selectedUsernameSocial === username && (
                                      <div className="w-1.5 h-1.5 bg-white rounded-full" />
                                    )}
                                  </div>
                                </td>
                                <td className="p-2 font-medium">{username}</td>
                                <td className="p-2 text-xs">
                                  {taken ? (
                                    <span className="text-red-600 font-semibold">Đã tồn tại</span>
                                  ) : (
                                    <span className="text-green-600">Sẵn sàng</span>
                                  )}
                                </td>
                              </tr>
                            )
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                ) : (
                  <div className="p-8 border-2 border-dashed rounded-lg text-center text-gray-400 bg-gray-50">
                    (Chọn Group Để Hiển Thị Danh Sách Username)
                  </div>
                )}
              </div>
            </div>

            {/* Step 2: Select Content */}
            <div className="space-y-4 pt-4 border-t">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="h-5 w-5 rounded-full p-0 flex items-center justify-center bg-[#1e9df1] text-white border-[#1e9df1]"
                >
                  2
                </Badge>
                Select Content
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="folder-name">Folder Image Name*</Label>
                  <Input
                    id="folder-name"
                    value={selectedUsernameSocial}
                    readOnly
                    className="bg-gray-50 cursor-not-allowed"
                    placeholder="Auto-filled from Username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="idea">Select Idea *</Label>
                  <Select
                    onValueChange={(val) => {
                      setSelectedIdea(val)
                      setSelectedNiche([])
                    }}
                    value={selectedIdea}
                  >
                    <SelectTrigger id="idea">
                      <SelectValue placeholder="Select Idea" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(autoSyncData).map((idea) => (
                        <SelectItem key={idea} value={idea}>
                          {idea}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="niche">Select Niche * (Can select multiple)</Label>
                  <Select
                    onValueChange={(val) => {
                      if (selectedNiche.includes(val)) {
                        setSelectedNiche(selectedNiche.filter((n) => n !== val))
                      } else {
                        setSelectedNiche([...selectedNiche, val])
                      }
                    }}
                    disabled={!selectedIdea}
                  >
                    <SelectTrigger id="niche" className={!selectedIdea ? "opacity-50" : ""}>
                      <SelectValue
                        placeholder={selectedNiche.length > 0 ? `${selectedNiche.length} selected` : "Select Niche"}
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {selectedIdea &&
                        Object.keys(autoSyncData[selectedIdea]).map((niche) => (
                          <SelectItem
                            key={niche}
                            value={niche}
                            className={`flex items-center justify-between ${selectedNiche.includes(niche) ? "bg-purple-100 text-purple-700 font-medium" : ""}`}
                          >
                            <div className="flex items-center gap-2">
                              {selectedNiche.includes(niche) && <Check className="h-4 w-4" />}
                              <span>{niche}</span>
                            </div>
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  {selectedNiche.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1 max-h-16 overflow-y-auto">
                      {selectedNiche.map((n) => (
                        <Badge key={n} variant="secondary" className="text-[10px] py-0 px-1">
                          {n}
                          <X
                            className="ml-1 h-2 w-2 cursor-pointer"
                            onClick={() => setSelectedNiche(selectedNiche.filter((i) => i !== n))}
                          />
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Content Type Status Indicators */}
              <div className="grid grid-cols-3 gap-4 pt-2">
                <div
                  className={`p-2 rounded-md border text-center text-xs font-medium transition-all ${selectedUsernameSocial ? "bg-green-50 border-green-200 text-green-700 opacity-100" : "bg-gray-50 border-gray-100 text-gray-400 opacity-40"}`}
                >
                  1 New (Square)
                </div>
                <div
                  className={`p-2 rounded-md border text-center text-xs font-medium transition-all ${selectedUsernameSocial ? "bg-blue-50 border-blue-200 text-blue-700 opacity-100" : "bg-gray-50 border-gray-100 text-gray-400 opacity-40"}`}
                >
                  2 Reel (Vertical)
                </div>
                <div
                  className={`p-2 rounded-md border text-center text-xs font-medium transition-all ${selectedUsernameSocial ? "bg-purple-50 border-purple-200 text-purple-700 opacity-100" : "bg-gray-50 border-gray-100 text-gray-400 opacity-40"}`}
                >
                  3 Square Product
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-2">
                {/* New (Square) Config */}
                <div className="border-2 border-green-200 rounded-xl p-4 space-y-4 bg-green-50/50">
                  <div className="flex items-center justify-between border-b border-green-200 pb-2">
                    <span className="text-sm font-bold text-green-700">Type Post: New</span>
                    <span className="text-xs font-medium text-gray-500 bg-white px-2 py-0.5 rounded border border-gray-200">
                      🕐 US Timezone
                    </span>
                  </div>

                  {/* Day Of Weeks */}
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-gray-700">Day Of Weeks:</div>
                    <div className="grid grid-cols-4 gap-2">
                      {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                        <label
                          key={day}
                          className="flex items-center gap-1.5 cursor-pointer bg-white rounded-md px-2 py-1.5 border border-green-200 hover:bg-green-100 transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={contentTypeConfigs.new.dayOfWeeks.includes(day)}
                            onChange={() => toggleDayOfWeek("new", day)}
                            className="w-4 h-4 rounded accent-green-600"
                          />
                          <span className="text-xs font-medium">{day}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Time Range */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-700">Time Range:</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs px-3 bg-white border-green-300 text-green-700 hover:bg-green-100"
                        onClick={() => addTimeRange("new")}
                      >
                        + Add Interval
                      </Button>
                    </div>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {contentTypeConfigs.new.timeRanges.map((range, idx) => (
                        <div
                          key={idx}
                          className="flex items-center gap-2 bg-white rounded-md p-2 border border-green-200"
                        >
                          <input
                            type="time"
                            value={range.from}
                            onChange={(e) => updateTimeRange("new", idx, "from", e.target.value)}
                            className="text-xs border border-gray-300 rounded-md px-2 py-1.5 w-28 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                          />
                          <span className="text-xs font-medium text-gray-500">to</span>
                          <input
                            type="time"
                            value={range.to}
                            onChange={(e) => updateTimeRange("new", idx, "to", e.target.value)}
                            className="text-xs border border-gray-300 rounded-md px-2 py-1.5 w-28 focus:ring-2 focus:ring-green-500 focus:border-green-500"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              // Random time between 5-10 hours interval
                              const randomStart = Math.floor(Math.random() * 12) + 6 // 6:00 - 18:00
                              const randomInterval = Math.floor(Math.random() * 6) + 5 // 5-10 hours
                              const randomEnd = Math.min(randomStart + randomInterval, 23)
                              const fromTime = `${randomStart.toString().padStart(2, "0")}:00`
                              const toTime = `${randomEnd.toString().padStart(2, "0")}:00`
                              updateTimeRange("new", idx, "from", fromTime)
                              updateTimeRange("new", idx, "to", toTime)
                            }}
                            className="text-green-600 hover:text-green-800 hover:bg-green-100 rounded-full p-1 transition-colors"
                            title="Random Time (5-10 hours interval)"
                          >
                            <Shuffle className="w-4 h-4" />
                          </button>
                          {contentTypeConfigs.new.timeRanges.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeTimeRange("new", idx)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full p-1 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Reel (Vertical) Config */}
                <div className="border-2 border-blue-200 rounded-xl p-4 space-y-4 bg-blue-50/50">
                  <div className="flex items-center justify-between border-b border-blue-200 pb-2">
                    <span className="text-sm font-bold text-blue-700">Type Post: Reel</span>
                    <span className="text-xs font-medium text-gray-500 bg-white px-2 py-0.5 rounded border border-gray-200">
                      🕐 US Timezone
                    </span>
                  </div>

                  {/* Day Of Weeks */}
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-gray-700">Day Of Weeks:</div>
                    <div className="grid grid-cols-4 gap-2">
                      {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                        <label
                          key={day}
                          className="flex items-center gap-1.5 cursor-pointer bg-white rounded-md px-2 py-1.5 border border-blue-200 hover:bg-blue-100 transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={contentTypeConfigs.reel.dayOfWeeks.includes(day)}
                            onChange={() => toggleDayOfWeek("reel", day)}
                            className="w-4 h-4 rounded accent-blue-600"
                          />
                          <span className="text-xs font-medium">{day}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Time Range */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-700">Time Range:</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs px-3 bg-white border-blue-300 text-blue-700 hover:bg-blue-100"
                        onClick={() => addTimeRange("reel")}
                      >
                        + Add Interval
                      </Button>
                    </div>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {contentTypeConfigs.reel.timeRanges.map((range, idx) => (
                        <div
                          key={idx}
                          className="flex items-center gap-2 bg-white rounded-md p-2 border border-blue-200"
                        >
                          <input
                            type="time"
                            value={range.from}
                            onChange={(e) => updateTimeRange("reel", idx, "from", e.target.value)}
                            className="text-xs border border-gray-300 rounded-md px-2 py-1.5 w-28 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                          <span className="text-xs font-medium text-gray-500">to</span>
                          <input
                            type="time"
                            value={range.to}
                            onChange={(e) => updateTimeRange("reel", idx, "to", e.target.value)}
                            className="text-xs border border-gray-300 rounded-md px-2 py-1.5 w-28 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              // Random time between 5-10 hours interval
                              const randomStart = Math.floor(Math.random() * 12) + 6 // 6:00 - 18:00
                              const randomInterval = Math.floor(Math.random() * 6) + 5 // 5-10 hours
                              const randomEnd = Math.min(randomStart + randomInterval, 23)
                              const fromTime = `${randomStart.toString().padStart(2, "0")}:00`
                              const toTime = `${randomEnd.toString().padStart(2, "0")}:00`
                              updateTimeRange("reel", idx, "from", fromTime)
                              updateTimeRange("reel", idx, "to", toTime)
                            }}
                            className="text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full p-1 transition-colors"
                            title="Random Time (5-10 hours interval)"
                          >
                            <Shuffle className="w-4 h-4" />
                          </button>
                          {contentTypeConfigs.reel.timeRanges.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeTimeRange("reel", idx)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full p-1 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Square Product Config */}
                <div className="border-2 border-purple-200 rounded-xl p-4 space-y-4 bg-purple-50/50">
                  <div className="flex items-center justify-between border-b border-purple-200 pb-2">
                    <span className="text-sm font-bold text-purple-700">Type Post: Square Product</span>
                    <span className="text-xs font-medium text-gray-500 bg-white px-2 py-0.5 rounded border border-gray-200">
                      🕐 US Timezone
                    </span>
                  </div>

                  {/* Day Of Weeks */}
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-gray-700">Day Of Weeks:</div>
                    <div className="grid grid-cols-4 gap-2">
                      {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                        <label
                          key={day}
                          className="flex items-center gap-1.5 cursor-pointer bg-white rounded-md px-2 py-1.5 border border-purple-200 hover:bg-purple-100 transition-colors"
                        >
                          <input
                            type="checkbox"
                            checked={contentTypeConfigs.squareProduct.dayOfWeeks.includes(day)}
                            onChange={() => toggleDayOfWeek("squareProduct", day)}
                            className="w-4 h-4 rounded accent-purple-600"
                          />
                          <span className="text-xs font-medium">{day}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Time Range */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-700">Time Range:</span>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs px-3 bg-white border-purple-300 text-purple-700 hover:bg-purple-100"
                        onClick={() => addTimeRange("squareProduct")}
                      >
                        + Add Interval
                      </Button>
                    </div>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {contentTypeConfigs.squareProduct.timeRanges.map((range, idx) => (
                        <div
                          key={idx}
                          className="flex items-center gap-2 bg-white rounded-md p-2 border border-purple-200"
                        >
                          <input
                            type="time"
                            value={range.from}
                            onChange={(e) => updateTimeRange("squareProduct", idx, "from", e.target.value)}
                            className="text-xs border border-gray-300 rounded-md px-2 py-1.5 w-28 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                          />
                          <span className="text-xs font-medium text-gray-500">to</span>
                          <input
                            type="time"
                            value={range.to}
                            onChange={(e) => updateTimeRange("squareProduct", idx, "to", e.target.value)}
                            className="text-xs border border-gray-300 rounded-md px-2 py-1.5 w-28 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              // Random time between 5-10 hours interval
                              const randomStart = Math.floor(Math.random() * 12) + 6 // 6:00 - 18:00
                              const randomInterval = Math.floor(Math.random() * 6) + 5 // 5-10 hours
                              const randomEnd = Math.min(randomStart + randomInterval, 23)
                              const fromTime = `${randomStart.toString().padStart(2, "0")}:00`
                              const toTime = `${randomEnd.toString().padStart(2, "0")}:00`
                              updateTimeRange("squareProduct", idx, "from", fromTime)
                              updateTimeRange("squareProduct", idx, "to", toTime)
                            }}
                            className="text-purple-600 hover:text-purple-800 hover:bg-purple-100 rounded-full p-1 transition-colors"
                            title="Random Time (5-10 hours interval)"
                          >
                            <Shuffle className="w-4 h-4" />
                          </button>
                          {contentTypeConfigs.squareProduct.timeRanges.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeTimeRange("squareProduct", idx)}
                              className="text-red-500 hover:text-red-700 hover:bg-red-50 rounded-full p-1 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Step 3: Auto-Sync Information */}
            <div className="space-y-4 pt-4 border-t">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="h-5 w-5 rounded-full p-0 flex items-center justify-center bg-[#1e9df1] text-white border-[#1e9df1]"
                >
                  3
                </Badge>
                3. Auto-Sync Information{" "}
                <span className="text-gray-600 font-normal">
                  (Thông Tin Sẽ Tự Động Sync Từ Username Social {"&"} Member By)
                </span>
              </h3>

              <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div className="flex items-center gap-4">
                  <Label className="w-24 shrink-0 text-right">Type*</Label>
                  <Input readOnly value={autoSyncInfo.type} className="bg-gray-50" />
                </div>
                <div className="flex items-center gap-4">
                  <Label className="w-32 shrink-0 text-right">Department*</Label>
                  <Input readOnly value={autoSyncInfo.department} className="bg-gray-50" />
                </div>
                <div className="flex items-center gap-4">
                  <Label className="w-24 shrink-0 text-right">Team*</Label>
                  <Input readOnly value={autoSyncInfo.team} className="bg-gray-50" />
                </div>
                <div className="flex items-center gap-4">
                  <Label className="w-32 shrink-0 text-right">Leader*</Label>
                  <Input readOnly value={autoSyncInfo.leader} className="bg-gray-50" />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="p-6 border-t shrink-0 flex items-center justify-end gap-3 bg-gray-50 sm:justify-end sticky bottom-0 z-20">
            <Button variant="outline" onClick={() => setIsCreateModalOpen(false)} className="w-32">
              Cancel
            </Button>
            <Button
              onClick={handleCreateNew}
              className="w-32 bg-[#509485] hover:bg-[#3e7d71] text-white"
              disabled={!selectedUsernameSocial || !activeTab || !selectedIdea || selectedNiche.length === 0}
            >
              Create New
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="max-w-7xl max-h-[90vh] p-0 overflow-hidden flex flex-col z-50">
          <DialogHeader className="p-6 border-b shrink-0 sticky top-0 bg-white z-20">
            <DialogTitle className="text-xl">Edit Works Folder Image</DialogTitle>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Step 1: Social Platform Selection */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="h-5 w-5 rounded-full p-0 flex items-center justify-center bg-[#1e9df1] text-white border-[#1e9df1]"
                >
                  1
                </Badge>
                Edit Social Platform
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-social-platform">Social Platform</Label>
                  <div className="relative">
                    <Select value={editModal.accountSocial} disabled>
                      <SelectTrigger id="edit-social-platform" className="w-full bg-gray-50 cursor-not-allowed">
                        <SelectValue placeholder="Select platform" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.keys(socialPlatforms).map((platform) => (
                          <SelectItem key={platform} value={platform}>
                            {platformConfig[platform]?.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Lock className="absolute right-8 top-2.5 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-group-account" className="truncate block">
                    Group Account Social{" "}
                    <span className="text-gray-500 text-xs">(Select Group Show List Username)</span>
                  </Label>
                  <Select
                    value={editModal.groupAccountSocial}
                    onValueChange={(value) => {
                      setEditModal((prev) => ({
                        ...prev,
                        groupAccountSocial: value,
                        usernameSocial: "", // Reset username when group changes
                        folderName: "", // Also reset folder name if it's derived from username
                      }))
                    }}
                  >
                    <SelectTrigger id="edit-group-account">
                      <SelectValue placeholder="Select Group" />
                    </SelectTrigger>
                    <SelectContent>
                      {(groupMockData[editModal.accountSocial] || []).map((group) => (
                        <SelectItem key={group} value={group}>
                          {group}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-username-social">
                  Username Social*{" "}
                  <span className="text-gray-600 font-normal">
                    (Chọn 1 Account Social Duy Nhất - Tự Động Loại Bỏ Trùng Lặp)
                  </span>
                </Label>
                <Select
                  onValueChange={(val) => {
                    // Check if the selected username is taken by another item *other than* the current item being edited.
                    // This is important to allow re-selecting the same username if it's the current item's.
                    const isTakenByOther = ideaNiches.some(
                      (item) =>
                        item.usernameSocial === val &&
                        item.accountSocial === editModal.accountSocial &&
                        item.id !== editModal.item.id,
                    )

                    if (!isTakenByOther) {
                      setEditModal((prev) => ({ ...prev, usernameSocial: val, folderName: val }))
                    } else {
                      alert(`Username "${val}" is already taken by another entry for ${editModal.accountSocial}.`)
                    }
                  }}
                  value={editModal.usernameSocial}
                  disabled={!editModal.groupAccountSocial}
                >
                  <SelectTrigger
                    id="edit-username-social"
                    className={!editModal.groupAccountSocial ? "opacity-50" : ""}
                  >
                    <SelectValue
                      placeholder={
                        editModal.groupAccountSocial ? "Select Username" : "(Chọn Group Để Hiển Thị Danh Sách Username)"
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {editModal.groupAccountSocial &&
                      (usernamesByGroup[editModal.groupAccountSocial] || []).map((username) => (
                        <SelectItem key={username} value={username}>
                          {username}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Separator />

            {/* Step 2: Content Selection */}
            <div className="space-y-4 pt-4 border-t">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="h-5 w-5 rounded-full p-0 flex items-center justify-center bg-[#1e9df1] text-white border-[#1e9df1]"
                >
                  2
                </Badge>
                Edit Content
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-folder-name">Folder Image Name*</Label>
                  <Input
                    id="edit-folder-name"
                    value={editModal.usernameSocial}
                    readOnly
                    className="bg-gray-50 cursor-not-allowed"
                    placeholder="Auto-filled from Username"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-idea">Select Idea *</Label>
                  <Select
                    value={editModal.idea}
                    onValueChange={(value) => {
                      setEditModal((prev) => ({ ...prev, idea: value, niche: [] }))
                    }}
                  >
                    <SelectTrigger id="edit-idea">
                      <SelectValue placeholder="Select idea..." />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.keys(autoSyncData).map((idea) => (
                        <SelectItem key={idea} value={idea}>
                          {idea}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-niche">Select Niche * (Can select multiple)</Label>
                  <Select
                    onValueChange={(val) => {
                      if (editModal.niche.includes(val)) {
                        setEditModal((prev) => ({ ...prev, niche: prev.niche.filter((n) => n !== val) }))
                      } else {
                        setEditModal((prev) => ({ ...prev, niche: [...prev.niche, val] }))
                      }
                    }}
                    disabled={!editModal.idea}
                  >
                    <SelectTrigger id="edit-niche" className={!editModal.idea ? "opacity-50" : ""}>
                      <SelectValue
                        placeholder={editModal.niche.length > 0 ? `${editModal.niche.length} selected` : "Select Niche"}
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {editModal.idea &&
                        Object.keys(autoSyncData[editModal.idea]).map((niche) => (
                          <SelectItem
                            key={niche}
                            value={niche}
                            className={`flex items-center justify-between ${editModal.niche.includes(niche) ? "bg-purple-100 text-purple-700 font-medium" : ""}`}
                          >
                            <div className="flex items-center gap-2">
                              {editModal.niche.includes(niche) && <Check className="h-4 w-4" />}
                              <span>{niche}</span>
                            </div>
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                  {editModal.niche.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1 max-h-16 overflow-y-auto">
                      {editModal.niche.map((n) => (
                        <Badge key={n} variant="secondary" className="text-[10px] py-0 px-1">
                          {n}
                          <X
                            className="ml-1 h-2 w-2 cursor-pointer"
                            onClick={() =>
                              setEditModal((prev) => ({ ...prev, niche: prev.niche.filter((i) => i !== n) }))
                            }
                          />
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <Separator />

            {/* Step 3: Auto-Sync Information */}
            <div className="space-y-4 pt-4 border-t">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Badge
                  variant="outline"
                  className="h-5 w-5 rounded-full p-0 flex items-center justify-center bg-[#1e9df1] text-white border-[#1e9df1]"
                >
                  3
                </Badge>
                3. Auto-Sync Information{" "}
                <span className="text-gray-600 font-normal">
                  (Thông Tin Sẽ Tự Động Sync Từ Username Social {"&"} Member By)
                </span>
              </h3>

              <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div className="flex items-center gap-4">
                  <Label className="w-24 shrink-0 text-right">Type</Label>
                  <Input readOnly value={editModal.autoSyncInfo.type} className="bg-gray-50" />
                </div>
                <div className="flex items-center gap-4">
                  <Label className="w-32 shrink-0 text-right">Department</Label>
                  <Input readOnly value={editModal.autoSyncInfo.department} className="bg-gray-50" />
                </div>
                <div className="flex items-center gap-4">
                  <Label className="w-24 shrink-0 text-right">Team</Label>
                  <Input readOnly value={editModal.autoSyncInfo.team} className="bg-gray-50" />
                </div>
                <div className="flex items-center gap-4">
                  <Label className="w-32 shrink-0 text-right">Leader</Label>
                  <Input readOnly value={editModal.autoSyncInfo.leader} className="bg-gray-50" />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter className="p-6 border-t shrink-0 flex items-center justify-end gap-3 bg-gray-50 sm:justify-end sticky bottom-0 z-20">
            <Button
              variant="outline"
              onClick={() =>
                setEditModal({
                  isOpen: false,
                  item: null,
                  folderName: "",
                  model: "",
                  accountSocial: "",
                  usernameSocial: "",
                  groupAccountSocial: "",
                  idea: "",
                  niche: [],
                  autoSyncInfo: { type: "", department: "", team: "", leader: "" },
                  statusAccountSocial: "", // Reset these too
                  loginAppClone: "",
                })
              }
              className="w-32"
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdateItem}
              className="w-32"
              disabled={
                !editModal.usernameSocial || !editModal.accountSocial || !editModal.idea || editModal.niche.length === 0
              }
            >
              Update
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={createPostModal.isOpen}
        onOpenChange={(open) => !open && setCreatePostModal({ ...createPostModal, isOpen: false })}
      >
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">
              Create Instagram Post - {createPostModal.folderName}
            </DialogTitle>
            <p className="text-sm text-gray-500 mt-1">
              Post #{/* Calculate post number dynamically */}
              {(posts[`${createPostModal.ideaNicheId}-${createPostModal.folderType}`]?.length || 0) + 1}
            </p>
          </DialogHeader>

          <div className="space-y-6">
            {/* Caption Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="caption" className="text-sm font-semibold text-gray-700">
                  Caption
                </Label>
                <div className="flex items-center gap-3 text-xs">
                  <span className="text-[#91bfb4] font-semibold">
                    {(createPostModal.caption.match(/#\w+/g) || []).length} hashtags
                  </span>
                  <span className="text-gray-500">{createPostModal.caption.length} chars</span>
                  <span className="text-[#F7B928] font-semibold">
                    {(createPostModal.caption.match(/https?:\/\/[^\s]+/g) || []).length} Links
                  </span>
                </div>
              </div>
              <textarea
                id="caption"
                value={createPostModal.caption}
                onChange={(e) => setCreatePostModal({ ...createPostModal, caption: e.target.value })}
                placeholder="Write your Instagram caption here... Use hashtags (#) for better reach"
                className="w-full min-h-[140px] p-4 border-2 rounded-lg mt-1 resize-y focus:ring-2 focus:ring-[#91bfb4] focus:border-transparent transition-all"
              />
              <p className="text-xs text-gray-400">
                💡 Tip: Use relevant hashtags (starts with #) and @mentions to increase engagement
              </p>
            </div>

            {/* Media Upload Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold text-gray-700">Media Files (Images & Videos)</Label>
                <span className="text-xs text-gray-500">
                  {createPostModal.mediaFiles.length} file{createPostModal.mediaFiles.length !== 1 ? "s" : ""}
                </span>
              </div>

              <input
                type="file"
                multiple
                accept="image/*,video/*"
                onChange={handlePostMediaUpload}
                className="hidden"
                id="post-media-upload"
              />
              <label
                htmlFor="post-media-upload"
                className="flex flex-col items-center justify-center w-full h-40 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[#91bfb4] hover:bg-[#91bfb4]/5 transition-all group"
              >
                <Upload className="h-10 w-10 text-gray-400 group-hover:text-[#91bfb4] transition-colors mb-3" />
                <p className="text-sm font-medium text-gray-600 group-hover:text-[#91bfb4]">
                  Click to upload images or videos
                </p>
                <p className="text-xs text-gray-400 mt-2">Supports JPG, PNG, MP4, MOV • Multiple files allowed</p>
                <p className="text-xs-[#91bfb4] font-medium">⚠ Duplicate files will be automatically skipped</p>
              </label>
            </div>

            {/* Media Preview with Ordering */}
            {createPostModal.mediaFiles.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-semibold text-gray-700">Media Preview & Order</Label>
                  <span className="text-xs text-[#91bfb4] font-medium">Drag to reorder</span>
                </div>

                <div className="grid grid-cols-5 gap-3">
                  {createPostModal.mediaFiles
                    .sort((a, b) => a.order - b.order)
                    .map((media, index) => (
                      <div
                        key={media.id}
                        draggable
                        onDragStart={(e) => e.dataTransfer.setData("dragIndex", index)}
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault()
                          const dragIndex = Number.parseInt(e.dataTransfer.getData("dragIndex"))
                          handleReorderMedia(dragIndex, index)
                        }}
                        className="relative group cursor-move border-2 border-gray-200 rounded-lg hover:border-[#91bfb4] transition-all"
                      >
                        {/* Order Number Badge */}
                        <div className="absolute -top-2 -left-2 z-10 w-7 h-7 bg-[#91bfb4] text-white rounded-full flex items-center justify-center text-xs font-bold shadow-lg">
                          {media.order}
                        </div>

                        {media.type === "video" ? (
                          <div className="relative">
                            <video
                              src={media.url}
                              className="w-full h-28 object-cover rounded-md bg-black"
                              muted
                              playsInline
                              onMouseEnter={(e) => e.target.play()}
                              onMouseLeave={(e) => {
                                e.target.pause()
                                e.target.currentTime = 0
                              }}
                            />
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                              <div className="bg-black/60 rounded-full p-2">
                                <Play className="h-6 w-6 text-white" />
                              </div>
                            </div>
                            <div className="absolute top-1 right-1 bg-red-600 text-white text-[10px] px-2 py-1 rounded-md font-bold shadow-lg flex items-center gap-1">
                              <Film className="h-3 w-3" />
                              VIDEO
                            </div>
                          </div>
                        ) : (
                          <div className="relative">
                            <img
                              src={media.url || "/placeholder.svg"}
                              alt={`Media ${media.order}`}
                              className="w-full h-28 object-cover rounded-md"
                            />
                            <div className="absolute top-1 right-1 bg-blue-600 text-white text-[10px] px-2 py-1 rounded-md font-bold shadow-lg flex items-center gap-1">
                              <ImageIcon className="h-3 w-3" />
                              IMAGE
                            </div>
                          </div>
                        )}

                        {/* Remove Button */}
                        <button
                          onClick={() => handleRemovePostMedia(media.id)}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:bg-red-600 z-10"
                          title="Remove media"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                </div>

                <p className="text-xs text-gray-500 italic flex items-center gap-1">
                  <GripVertical className="h-3 w-3" />
                  Media will be posted to Instagram in this exact order
                </p>
              </div>
            )}
          </div>

          <DialogFooter className="flex justify-end gap-2 mt-6">
            <Button
              variant="outline"
              onClick={() => setCreatePostModal({ ...createPostModal, isOpen: false })}
              className="hover:bg-gray-100"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSavePost}
              disabled={!createPostModal.caption.trim() || createPostModal.mediaFiles.length === 0}
              className="bg-[#91bfb4] hover:bg-[#7aaca4] text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save className="h-4 w-4 mr-2" />
              Save Post
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={viewPostsModal.isOpen}
        onOpenChange={(open) => {
          if (!open) {
            setSelectedPostIds([])
          }
          setViewPostsModal({ ...viewPostsModal, isOpen: open })
        }}
      >
        <DialogContent className="max-w-[95vw] max-h-[98vh] p-0 overflow-hidden flex flex-col z-50">
          <div className="sticky top-0 z-10 bg-gradient-to-r from-purple-50 to-pink-50 border-b border-gray-200 shadow-md">
            <div className="px-6 py-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                  <FolderOpen className="h-5 w-5 text-white" />
                </div>
                <div>
                  <DialogTitle className="text-xl font-bold text-[#0F172A]">{viewPostsModal.folderName}</DialogTitle>
                  <p className="text-sm text-[#64748B]"> {viewPostsModal.posts.length} posts in library</p>
                </div>
              </div>
            </div>
            <div className="px-6 py-2 bg-white/60 border-t border-gray-200">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                {viewPostsModal.folderType === "subject" && (
                  <>
                    <span className="font-semibold text-green-600 bg-green-50 px-2 py-1 rounded">Type: New</span>
                    <span className="text-gray-300">|</span>
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="text-gray-500 text-xs">Time Range:</span>
                      <span className="text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs">09:00 - 11:00 AM</span>
                      <span className="text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs">07:00 - 09:00 PM</span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="text-gray-500 text-xs">Day Of Weeks:</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Mon</span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Tue</span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Wed</span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Thu</span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Fri</span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Sat</span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-green-600 bg-green-50 px-1.5 py-0.5 rounded text-xs font-medium">Sun</span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <span className="text-blue-600 bg-blue-50 px-2 py-1 rounded text-xs flex items-center gap-1">
                      <Clock className="h-3 w-3" /> US Timezone
                    </span>
                  </>
                )}
                {viewPostsModal.folderType === "scene" && (
                  <>
                    <span className="font-semibold text-purple-600 bg-purple-50 px-2 py-1 rounded">Type: Reel</span>
                    <span className="text-gray-300">|</span>
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="text-gray-500 text-xs">Time Range:</span>
                      <span className="text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs">12:00 - 02:00 PM</span>
                      <span className="text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs">09:30 - 11:30 PM</span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="text-gray-500 text-xs">Day Of Weeks:</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Mon
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Tue
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Wed
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Thu
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Fri
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Sat
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-purple-600 bg-purple-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Sun
                      </span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <span className="text-blue-600 bg-blue-50 px-2 py-1 rounded text-xs flex items-center gap-1">
                      <Clock className="h-3 w-3" /> US Timezone
                    </span>
                  </>
                )}
                {viewPostsModal.folderType === "style" && (
                  <>
                    <span className="font-semibold text-orange-600 bg-orange-50 px-2 py-1 rounded">
                      Type: Square Product
                    </span>
                    <span className="text-gray-300">|</span>
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="text-gray-500 text-xs">Time Range:</span>
                      <span className="text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs">06:00 - 08:00 AM</span>
                      <span className="text-gray-600 bg-gray-100 px-2 py-1 rounded text-xs">03:00 - 05:00 PM</span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <div className="flex flex-wrap items-center gap-1">
                      <span className="text-gray-500 text-xs">Day Of Weeks:</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Mon
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Tue
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Wed
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Thu
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Fri
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Sat
                      </span>
                      <span className="text-gray-400">{">"}</span>
                      <span className="text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded text-xs font-medium">
                        Sun
                      </span>
                    </div>
                    <span className="text-gray-300">|</span>
                    <span className="text-blue-600 bg-blue-50 px-2 py-1 rounded text-xs flex items-center gap-1">
                      <Clock className="h-3 w-3" /> US Timezone
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex h-[calc(98vh-150px)]">
            {" "}
            {/* Adjusted height calculation */}
            <div className="w-[450px] bg-[#F8FAFC] border-r border-[#CBD5E1] flex flex-col shrink-0">
              <div className="px-4 py-3 bg-white border-b border-[#CBD5E1]">
                <div className="flex items-center justify-between gap-3 mb-2">
                  <h3 className="text-sm font-semibold text-[#0F172A] uppercase tracking-wide whitespace-nowrap">
                    Posts Library
                  </h3>
                </div>
                <div className="flex items-center gap-2 flex-nowrap">
                  <Checkbox
                    checked={viewPostsModal.posts.length > 0 && selectedPostIds.length === viewPostsModal.posts.length}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedPostIds(viewPostsModal.posts.map((p) => p.id))
                      } else {
                        setSelectedPostIds([])
                      }
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="flex-shrink-0"
                  />
                  <span className="text-xs text-gray-600 whitespace-nowrap">All</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    disabled={selectedPostIds.length === 0}
                    onClick={(e) => {
                      e.stopPropagation()
                      const rect = e.currentTarget.getBoundingClientRect()
                      setDeleteConfirmation({
                        isOpen: true,
                        type: "bulk",
                        position: { top: rect.bottom + 5, left: rect.left },
                      })
                    }}
                    className={`h-7 px-2 flex-shrink-0 flex items-center gap-1 ${
                      selectedPostIds.length === 0 ? "opacity-40" : "opacity-100 hover:bg-red-50"
                    }`}
                  >
                    <Trash2 className={`h-4 w-4 ${selectedPostIds.length > 0 ? "text-red-600" : ""}`} />
                    {selectedPostIds.length > 0 && (
                      <span className="text-xs font-bold text-red-600">({selectedPostIds.length})</span>
                    )}
                  </Button>
                  <Select onValueChange={handleBulkStatusEdit} disabled={selectedPostIds.length === 0}>
                    <SelectTrigger
                      className={`w-[130px] h-8 text-xs flex-shrink-0 transition-opacity ${
                        selectedPostIds.length === 0 ? "opacity-40" : "opacity-100"
                      }`}
                    >
                      <SelectValue placeholder="Status Edit" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Draft">Set to Draft</SelectItem>
                      <SelectItem value="Use">Set to Use</SelectItem>
                      <SelectItem value="Posted">Set to Posted</SelectItem>
                      <SelectItem value="Posting Error">Set to Posting Error</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[130px] h-8 text-xs flex-shrink-0">
                      <SelectValue placeholder="All Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Draft">Draft</SelectItem>
                      <SelectItem value="Use">Use</SelectItem>
                      <SelectItem value="Posted">Posted</SelectItem>
                      <SelectItem value="Posting Error">Posting Error</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {getFilteredPosts().length === 0 ? (
                  <div className="flex-1 flex items-center justify-center p-4">
                    <div className="text-center">
                      <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-gray-200 flex items-center justify-center">
                        <FileImage className="h-8 w-8 text-gray-400" />
                      </div>
                      <p className="text-xs text-gray-500 mb-3">No posts found matching your criteria</p>
                    </div>
                  </div>
                ) : (
                  getFilteredPosts()
                    .slice(
                      (viewPostsModal.currentPage - 1) * viewPostsModal.postsPerPage,
                      viewPostsModal.currentPage * viewPostsModal.postsPerPage,
                    )
                    .map((post, postIndex) => {
                      const isSelected = viewPostsModal.selectedPostIndex === postIndex
                      const isChecked = selectedPostIds.includes(post.id)
                      return (
                        <div
                          key={post.id}
                          className={`w-full rounded-lg border-2 transition-all ${
                            isSelected
                              ? "border-2 ring-2 ring-blue-500"
                              : "border-[#E5E7EB] bg-white hover:border-[#CBD5E1] hover:shadow-sm"
                          }`}
                        >
                          <div className="flex items-center gap-3 p-3 border-b border-gray-100">
                            <Checkbox
                              checked={isChecked}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedPostIds((prev) => [...prev, post.id])
                                } else {
                                  setSelectedPostIds((prev) => prev.filter((id) => id !== post.id))
                                }
                              }}
                              onClick={(e) => e.stopPropagation()}
                            />
                            <span
                              className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium border ${
                                getStatusBadge(post.status).color
                              }`}
                            >
                              {getStatusBadge(post.status).label}
                            </span>
                            <div className="ml-auto px-3 py-1 bg-gradient-to-br from-[#91bfb4] to-[#6a9a8f] text-white rounded-full text-xs font-bold shadow">
                              #{post.postNumber}
                            </div>
                            {/* CHANGE: Added confirmation dialog to individual trash icon */}
                            <div className="relative">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  const rect = e.currentTarget.getBoundingClientRect()
                                  setDeleteConfirmation({
                                    isOpen: true,
                                    type: "single",
                                    postId: post.id,
                                    postNumber: post.postNumber,
                                    position: { top: rect.bottom + 5, left: rect.left },
                                  })
                                }}
                                className="h-7 w-7 p-0 flex-shrink-0 hover:bg-red-50 hover:text-red-600"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </div>

                          {/* CHANGE: Increased label font size from text-[10px] to text-xs for better readability */}
                          <div className="flex items-center justify-between px-3 py-2 bg-gray-50 border-b border-gray-100 text-xs">
                            <div className="text-gray-600 font-medium">
                              <span className="text-xs text-gray-500">Create:</span>{" "}
                              {post.createdAt
                                ? new Date(post.createdAt).toLocaleDateString("en-GB", {
                                    day: "2-digit",
                                    month: "2-digit",
                                    year: "numeric",
                                  }) +
                                  " " +
                                  new Date(post.createdAt).toLocaleTimeString("en-GB", {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })
                                : "DD/MM/YYYY HH:MM"}
                            </div>
                            <div className="text-blue-600 font-medium">
                              <span className="text-xs text-blue-500">Updated:</span>{" "}
                              {post.updatedAt && post.status !== "Draft"
                                ? new Date(post.updatedAt).toLocaleDateString("en-GB", {
                                    day: "2-digit",
                                    month: "2-digit",
                                    year: "numeric",
                                  }) +
                                  " " +
                                  new Date(post.updatedAt).toLocaleTimeString("en-GB", {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })
                                : "DD/MM/YYYY HH:MM"}
                            </div>
                          </div>

                          {/* Row 2: Media Files */}
                          <button
                            onClick={() =>
                              setViewPostsModal({
                                ...viewPostsModal,
                                selectedPostIndex: postIndex,
                              })
                            }
                            className="w-full text-left"
                          >
                            <div className="p-3 border-b border-gray-100">
                              <div className="flex items-center gap-2 flex-wrap">
                                {post.mediaFiles.length > 0 ? (
                                  <>
                                    {post.mediaFiles.slice(0, 4).map((media, idx) => (
                                      <div
                                        key={idx}
                                        className="relative w-12 h-12 rounded overflow-hidden border border-gray-200"
                                      >
                                        {media.type === "video" ? (
                                          <div className="w-full h-full bg-gray-900 flex items-center justify-center">
                                            <Play className="h-5 w-5 text-white" />
                                          </div>
                                        ) : (
                                          <img
                                            src={media.url || "/placeholder.svg"}
                                            alt=""
                                            className="w-full h-full object-cover"
                                          />
                                        )}
                                      </div>
                                    ))}
                                    {post.mediaFiles.length > 4 && (
                                      <span className="text-xs text-gray-500 font-medium">
                                        +{post.mediaFiles.length - 4} more
                                      </span>
                                    )}
                                  </>
                                ) : (
                                  <span className="text-xs text-gray-400 italic">No media files</span>
                                )}
                              </div>
                            </div>

                            {/* Row 3: Caption */}
                            <div className="p-3">
                              <p className="text-xs text-gray-600 line-clamp-2 leading-relaxed">
                                {post.caption || <span className="italic text-gray-400">No caption</span>}
                              </p>
                            </div>
                          </button>
                        </div>
                      )
                    })
                )}
              </div>

              {/* Pagination Footer */}
              <div className="px-4 py-3 bg-white border-t border-[#CBD5E1] flex items-center justify-between text-xs text-gray-600">
                <div className="flex items-center gap-3">
                  <span>
                    {getFilteredPosts().length > 0
                      ? `${(viewPostsModal.currentPage - 1) * viewPostsModal.postsPerPage + 1} to ${Math.min(viewPostsModal.currentPage * viewPostsModal.postsPerPage, getFilteredPosts().length)} of ${getFilteredPosts().length}`
                      : "0"}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      setViewPostsModal({
                        ...viewPostsModal,
                        currentPage: Math.max(1, viewPostsModal.currentPage - 1),
                      })
                    }
                    disabled={viewPostsModal.currentPage === 1}
                    className="px-2 py-1 rounded hover:bg-gray-100 disabled:opacity-50"
                  >
                    ◀
                  </button>
                  {Array.from({ length: Math.ceil(getFilteredPosts().length / viewPostsModal.postsPerPage) || 1 }).map(
                    (_, i) => (
                      <button
                        key={i + 1}
                        onClick={() => setViewPostsModal({ ...viewPostsModal, currentPage: i + 1 })}
                        className={`px-2 py-1 rounded ${viewPostsModal.currentPage === i + 1 ? "bg-purple-500 text-white" : "hover:bg-gray-100"}`}
                      >
                        {i + 1}
                      </button>
                    ),
                  )}
                  <button
                    onClick={() =>
                      setViewPostsModal({
                        ...viewPostsModal,
                        currentPage: Math.min(
                          Math.ceil(getFilteredPosts().length / viewPostsModal.postsPerPage) || 1,
                          viewPostsModal.currentPage + 1,
                        ),
                      })
                    }
                    disabled={
                      viewPostsModal.currentPage ===
                        Math.ceil(getFilteredPosts().length / viewPostsModal.postsPerPage) ||
                      getFilteredPosts().length === 0
                    }
                    className="px-2 py-1 rounded hover:bg-gray-100 disabled:opacity-50"
                  >
                    ▶
                  </button>
                  <span className="mx-1">│</span>
                  <Select
                    value={viewPostsModal.postsPerPage.toString()}
                    onValueChange={(val) =>
                      setViewPostsModal({ ...viewPostsModal, postsPerPage: Number.parseInt(val), currentPage: 1 })
                    }
                  >
                    <SelectTrigger className="w-[60px] h-7 text-xs">
                      <SelectValue>{viewPostsModal.postsPerPage}</SelectValue>
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="20">20</SelectItem>
                      <SelectItem value="50">50</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            {/* Right Panel - Post Detail */}
            <div className="flex-1 overflow-y-auto bg-white">
              {viewPostsModal.posts.length > 0 &&
              viewPostsModal.selectedPostIndex >= 0 &&
              viewPostsModal.selectedPostIndex < viewPostsModal.posts.length ? (
                (() => {
                  const post = viewPostsModal.posts[viewPostsModal.selectedPostIndex]
                  const isPostEditable = (status) => {
                    const s = status?.toLowerCase()
                    return s === "draft" || s === "posting error"
                  }
                  const statusInfo = getStatusInfo(post.status)

                  return (
                    <div>
                      {/* User Guide - Collapsible */}
                      <div className="px-6 pt-4">
                        <button
                          onClick={() => setViewGuideVisible(!viewGuideVisible)}
                          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 text-purple-700 font-medium transition-all border border-purple-200 w-full justify-center shadow-sm"
                        >
                          {viewGuideVisible ? (
                            <>
                              <ChevronDown className="h-4 w-4" />
                              <span className="text-sm">Ẩn hướng dẫn sử dụng</span>
                            </>
                          ) : (
                            <>
                              <ChevronRight className="h-4 w-4" />
                              <span className="text-sm">Hiển thị hướng dẫn sử dụng</span>
                            </>
                          )}
                        </button>

                        {viewGuideVisible && (
                          <div className="mt-3 p-5 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 rounded-lg border border-purple-200 shadow-sm">
                            <h4 className="font-bold text-purple-900 mb-3 flex items-center gap-2">
                              <Info className="h-5 w-5" />
                              Hướng dẫn sử dụng Popup "View"
                            </h4>

                            <div className="space-y-3 text-sm text-gray-700">
                              {/* Posts Library */}
                              <div className="bg-white/70 p-3 rounded-lg">
                                <p className="font-semibold text-purple-800 mb-1">📚 Posts Library:</p>
                                <ul className="list-disc list-inside space-y-1 ml-2">
                                  <li>Click vào từng card để xem chi tiết Post</li>
                                  <li>Checkbox để chọn nhiều Posts cùng lúc</li>
                                  <li>Nút "Status Edit" để thay đổi Status hàng loạt</li>
                                </ul>
                              </div>

                              {/* Caption */}
                              <div className="bg-white/70 p-3 rounded-lg">
                                <p className="font-semibold text-blue-800 mb-1">✏️ Caption:</p>
                                <ul className="list-disc list-inside space-y-1 ml-2">
                                  <li>
                                    <strong>Draft/Posting Error:</strong> Có thể edit caption trực tiếp
                                  </li>
                                  <li>
                                    <strong>Use/Posted:</strong> Read Only, không edit được
                                  </li>
                                  <li>Hiển thị: Chars (số ký tự) và Hashtag (số lượng #)</li>
                                </ul>
                              </div>

                              {/* Media Files */}
                              <div className="bg-white/70 p-3 rounded-lg">
                                <p className="font-semibold text-amber-800 mb-1">🖼️ Media Files:</p>
                                <ul className="list-disc list-inside space-y-1 ml-2">
                                  <li>
                                    <strong>Tải thêm:</strong> Chỉ khi Draft/Posting Error (tối đa 10 files cùng lúc)
                                  </li>
                                  <li>
                                    <strong>Xóa media:</strong> Click nút X trên mỗi ảnh/video
                                  </li>
                                  <li>
                                    <strong>Sắp xếp:</strong> Kéo thả (drag & drop) để đổi vị trí
                                  </li>
                                  <li>
                                    <strong>Read Only:</strong> Use/Posted không chỉnh sửa được
                                  </li>
                                </ul>
                              </div>

                              {/* Carousel Social */}
                              <div className="bg-white/70 p-3 rounded-lg">
                                <p className="font-semibold text-pink-800 mb-1">📱 Carousel Social:</p>
                                <ul className="list-disc list-inside space-y-1 ml-2">
                                  <li>Xem preview các media theo thứ tự từ Trái → Phải</li>
                                  <li>Số thứ tự hiển thị: 1 → 2 → 3 → ...</li>
                                  <li>Giúp kiểm tra thứ tự hiển thị trước khi đăng</li>
                                </ul>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Caption Section */}
                      <div className="px-6 pt-4">
                        <button
                          onClick={() => setIsCaptionCollapsed(!isCaptionCollapsed)}
                          className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 rounded-lg transition-all border border-blue-200 shadow-sm"
                        >
                          <span className="flex items-center gap-3 font-semibold text-blue-900">
                            <FileText className="h-5 w-5" />
                            Caption
                            <span className="px-2.5 py-1 rounded-full bg-blue-500 text-white text-xs font-bold shadow-sm">
                              Chars: {post.caption?.length || 0}
                            </span>
                            <span className="px-2.5 py-1 rounded-full bg-emerald-500 text-white text-xs font-bold shadow-sm">
                              Hashtag: {(post.caption?.match(/#\w+/g) || []).length}
                            </span>
                            <span className="inline-flex items-center px-2.5 py-1 rounded-md bg-violet-100 text-violet-700 text-xs font-medium">
                              Links: {(post.caption?.match(/https?:\/\/[^\s]+/g) || []).length}
                            </span>
                            {!isPostEditable(post.status) && (
                              <span className="px-2 py-1 rounded-full bg-red-100 text-red-700 text-[10px] font-bold border border-red-300">
                                Read Only
                              </span>
                            )}
                          </span>
                          <ChevronDown
                            className={`h-5 w-5 text-blue-700 transition-transform ${isCaptionCollapsed ? "" : "rotate-180"}`}
                          />
                        </button>

                        <div
                          className="transition-all duration-300 overflow-hidden"
                          style={{ maxHeight: isCaptionCollapsed ? "180px" : "2000px" }}
                        >
                          <div className="mt-3 p-5 bg-white rounded-lg border border-gray-200 shadow-sm">
                            {post.caption && post.caption.trim() ? (
                              <textarea
                                value={post.caption}
                                onChange={(e) => {
                                  if (isPostEditable(post.status)) {
                                    setPosts((prev) => {
                                      const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`
                                      return {
                                        ...prev,
                                        [key]: prev[key].map((p) =>
                                          p.id === post.id ? { ...p, caption: e.target.value } : p,
                                        ),
                                      }
                                    })
                                    setViewPostsModal((prev) => ({
                                      ...prev,
                                      posts: prev.posts.map((p) =>
                                        p.id === post.id ? { ...p, caption: e.target.value } : p,
                                      ),
                                    }))
                                  }
                                }}
                                disabled={!isPostEditable(post.status)}
                                className={`w-full min-h-[150px] p-4 border-2 rounded-lg text-gray-800 whitespace-pre-wrap leading-relaxed resize-y focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                                  isPostEditable(post.status)
                                    ? "bg-white border-gray-300 hover:border-blue-400"
                                    : "bg-gray-50 border-gray-200 cursor-not-allowed opacity-75"
                                }`}
                                placeholder={isPostEditable(post.status) ? "Nhập caption của bạn..." : "No caption"}
                              />
                            ) : (
                              <div className="flex items-center justify-center py-8 text-gray-400 italic">
                                <FileX className="h-8 w-8 mr-2" />
                                No caption added yet...
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Media Files Section */}
                      <div className="px-6 pt-4">
                        <button
                          onClick={() => setIsMediaCollapsed(!isMediaCollapsed)}
                          className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-amber-50 hover:from-purple-100 hover:to-amber-100 rounded-lg transition-all border border-purple-200 shadow-sm"
                        >
                          <span className="flex items-center gap-3 font-semibold text-purple-900">
                            <ImageIcon className="h-5 w-5" />
                            Media Files
                            <span className="px-2.5 py-1 rounded-full bg-purple-500 text-white text-xs font-bold shadow-sm">
                              Image: {post.mediaFiles?.filter((m) => m.type === "image").length || 0}
                            </span>
                            <span className="px-2.5 py-1 rounded-full bg-amber-500 text-white text-xs font-bold shadow-sm">
                              Video: {post.mediaFiles?.filter((m) => m.type === "video").length || 0}
                            </span>
                            {!isPostEditable(post.status) && (
                              <span className="px-2 py-1 rounded-full bg-red-100 text-red-700 text-[10px] font-bold border border-red-300">
                                Read Only
                              </span>
                            )}
                          </span>
                          <ChevronDown
                            className={`h-5 w-5 text-purple-700 transition-transform ${isMediaCollapsed ? "" : "rotate-180"}`}
                          />
                        </button>

                        <div
                          className="transition-all duration-300 overflow-hidden"
                          style={{ maxHeight: isMediaCollapsed ? "220px" : "2000px" }}
                        >
                          <div className="mt-3 p-5 bg-white rounded-lg border border-gray-200 shadow-sm space-y-4">
                            {isPostEditable(post.status) && (
                              <div>
                                <label
                                  htmlFor={`upload-media-${post.id}`}
                                  className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg cursor-pointer hover:from-purple-600 hover:to-pink-600 transition-all shadow-md hover:shadow-lg"
                                >
                                  <Upload className="h-5 w-5" />
                                  <span className="font-bold text-base">Tải thêm ảnh/video</span>
                                </label>
                                <input
                                  id={`upload-media-${post.id}`}
                                  type="file"
                                  multiple
                                  accept="image/*,video/*"
                                  onChange={(e) => handleViewMediaUpload(post.id, e)}
                                  className="hidden"
                                />
                                <p className="text-center text-xs text-gray-500 mt-2 font-medium">
                                  Tối đa upload 10 files cùng lúc. - Hỗ trợ: JPG, PNG, MP4, MOV
                                </p>
                              </div>
                            )}

                            {post.mediaFiles && post.mediaFiles.length > 0 ? (
                              <>
                                <div className="grid grid-cols-4 gap-4">
                                  {post.mediaFiles
                                    .slice(0, showAllMedia[post.id] ? undefined : 4)
                                    .map((media, index) => (
                                      <div
                                        key={media.id}
                                        draggable={isPostEditable(post.status)}
                                        onDragStart={(e) => {
                                          if (isPostEditable(post.status)) {
                                            e.dataTransfer.setData("dragIndex", index)
                                          }
                                        }}
                                        onDragOver={(e) => {
                                          if (isPostEditable(post.status)) {
                                            e.preventDefault()
                                          }
                                        }}
                                        onDrop={(e) => {
                                          if (isPostEditable(post.status)) {
                                            e.preventDefault()
                                            const dragIndex = Number.parseInt(e.dataTransfer.getData("dragIndex"))
                                            handleReorderMediaInView(post.id, dragIndex, index)
                                          }
                                        }}
                                        className={`relative group rounded-xl overflow-hidden bg-gray-100 border-2 border-[#E5E7EB] hover:border-[#CBD5E1] transition-all duration-200 ${
                                          isPostEditable(post.status) ? "cursor-move" : "cursor-default"
                                        }`}
                                      >
                                        <div className="absolute top-2 left-2 z-10 w-7 h-7 bg-purple-600 text-white rounded-md flex items-center justify-center text-xs font-bold shadow">
                                          {media.order}
                                        </div>

                                        <div
                                          className="aspect-square cursor-pointer"
                                          onClick={() => {
                                            if (media.type === "video") {
                                              const videoEl = document.getElementById(`video-${media.id}`)
                                              if (videoEl) {
                                                if (videoEl.paused) videoEl.play()
                                                else videoEl.pause()
                                              }
                                            }
                                          }}
                                        >
                                          {media.type === "video" ? (
                                            <div className="relative w-full h-full flex items-center justify-center bg-black">
                                              <video
                                                id={`video-${media.id}`}
                                                src={media.url}
                                                className="max-w-full max-h-full object-contain rounded-lg"
                                              />
                                              <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                                <div className="bg-white/90 rounded-full p-2 shadow-lg">
                                                  <Play className="h-6 w-6 text-purple-600" />
                                                </div>
                                              </div>
                                            </div>
                                          ) : (
                                            <img
                                              src={media.url || "/placeholder.svg"}
                                              alt=""
                                              className="w-full h-full object-cover hover:scale-105 transition-transform"
                                            />
                                          )}
                                        </div>

                                        {isPostEditable(post.status) && (
                                          <button
                                            onClick={() => {
                                              const key = `${viewPostsModal.ideaNicheId}-${viewPostsModal.folderType}`
                                              setPosts((prev) => {
                                                const updatedPosts = prev[key].map((p) => {
                                                  if (p.id === post.id) {
                                                    const updatedMedia = p.mediaFiles
                                                      .filter((m) => m.id !== media.id)
                                                      .map((m, idx) => ({ ...m, order: idx + 1 }))
                                                    return { ...p, mediaFiles: updatedMedia }
                                                  }
                                                  return p
                                                })

                                                setViewPostsModal((prevModal) => ({
                                                  ...prevModal,
                                                  posts: updatedPosts,
                                                }))

                                                return {
                                                  ...prev,
                                                  [key]: updatedPosts,
                                                }
                                              })
                                            }}
                                            className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-7 h-7 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:bg-red-600 z-20"
                                            title="Delete media"
                                          >
                                            <X className="h-4 w-4" />
                                          </button>
                                        )}
                                      </div>
                                    ))}
                                </div>

                                {post.mediaFiles.length > 4 && (
                                  <button
                                    onClick={() => {
                                      setShowAllMedia((prev) => ({
                                        ...prev,
                                        [post.id]: !prev[post.id],
                                      }))
                                    }}
                                    className="w-full py-2 text-sm text-purple-600 hover:text-purple-700 font-semibold bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors"
                                  >
                                    {showAllMedia[post.id]
                                      ? "Ẩn bớt"
                                      : `Hiển thị thêm ${post.mediaFiles.length - 4} media`}
                                  </button>
                                )}
                              </>
                            ) : (
                              <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                                <FileImage className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                                <p className="text-sm text-gray-400">No media files</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Carousel Social - Post Data */}
                      <div className="px-6 pt-4">
                        <div className="mt-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200">
                          <div className="px-5 py-3 bg-white/80 backdrop-blur-sm border-b border-purple-200 flex items-center gap-2">
                            <Instagram className="h-5 w-5 text-purple-600" />
                            <span className="text-sm font-semibold text-purple-900">
                              Carousel Social{" "}
                              <span className="text-purple-400 font-normal">(bắt đầu chọn từ Trái → Phải)</span>
                            </span>
                            <span className="ml-auto text-xs text-purple-600 font-medium">
                              {post.mediaFiles?.length || 0} slides
                            </span>
                          </div>
                          <div className="p-6">
                            {post.mediaFiles && post.mediaFiles.length > 0 ? (
                              <div className="flex flex-wrap gap-3">
                                {post.mediaFiles
                                  .sort((a, b) => a.order - b.order)
                                  .map((media, index) => (
                                    <div
                                      key={media.id}
                                      className="relative group rounded-lg overflow-hidden bg-gray-100 border-2 border-purple-300 hover:border-purple-500 transition-all duration-200"
                                      style={{
                                        width:
                                          media.aspectRatio === "vertical"
                                            ? "150px"
                                            : media.aspectRatio === "horizontal"
                                              ? "280px"
                                              : "200px",
                                        flexShrink: 0,
                                      }}
                                    >
                                      <div className="absolute top-1 left-1 z-10 w-6 h-6 bg-purple-600 text-white rounded-md flex items-center justify-center text-xs font-bold shadow">
                                        {index + 1}
                                      </div>
                                      <div className="absolute bottom-1 right-1 z-10 px-2 py-0.5 bg-black/70 text-white rounded text-xs font-medium">
                                        {media.type === "video" ? "Video" : "Image"} {index + 1}
                                      </div>
                                      <div
                                        className={
                                          media.aspectRatio === "vertical"
                                            ? "aspect-[9/16]"
                                            : media.aspectRatio === "horizontal"
                                              ? "aspect-[16/9]"
                                              : "aspect-square"
                                        }
                                      >
                                        {media.type === "video" ? (
                                          <div className="relative w-full h-full flex items-center justify-center bg-black">
                                            <video src={media.url} className="w-full h-full object-cover" />
                                            <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                              <div className="bg-white/90 rounded-full p-1 shadow-lg">
                                                <Play className="h-4 w-4 text-purple-600" />
                                              </div>
                                            </div>
                                          </div>
                                        ) : (
                                          <img
                                            src={media.url || "/placeholder.svg"}
                                            alt={`Slide ${index + 1}`}
                                            className="w-full h-full object-cover"
                                          />
                                        )}
                                      </div>
                                    </div>
                                  ))}
                              </div>
                            ) : (
                              <div className="text-center py-8">
                                <FileImage className="h-12 w-12 mx-auto text-purple-300 mb-2" />
                                <p className="text-sm text-purple-600">No media to preview</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })()
              ) : (
                // Empty State
                <div className="flex-1 overflow-y-auto">
                  {/* User Guide */}
                  <div className="px-6 pt-4">
                    <button
                      onClick={() => setViewGuideVisible(!viewGuideVisible)}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 text-purple-700 font-medium transition-all border border-purple-200 w-full justify-center shadow-sm"
                    >
                      {viewGuideVisible ? (
                        <>
                          <ChevronDown className="h-4 w-4" />
                          <span className="text-sm">Ẩn hướng dẫn sử dụng</span>
                        </>
                      ) : (
                        <>
                          <ChevronRight className="h-4 w-4" />
                          <span className="text-sm">Hiển thị hướng dẫn sử dụng</span>
                        </>
                      )}
                    </button>

                    {viewGuideVisible && (
                      <div className="mt-3 p-5 bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 rounded-lg border border-purple-200 shadow-sm">
                        <h4 className="font-bold text-purple-900 mb-3 flex items-center gap-2">
                          <Info className="h-5 w-5" />
                          Hướng dẫn sử dụng Popup "View"
                        </h4>

                        <div className="space-y-3 text-sm text-gray-700">
                          {/* Posts Library */}
                          <div className="bg-white/70 p-3 rounded-lg">
                            <p className="font-semibold text-purple-800 mb-1">📚 Posts Library:</p>
                            <ul className="list-disc list-inside space-y-1 ml-2">
                              <li>Click vào từng card để xem chi tiết Post</li>
                              <li>Checkbox để chọn nhiều Posts cùng lúc</li>
                              <li>Nút "Status Edit" để thay đổi Status hàng loạt</li>
                            </ul>
                          </div>

                          {/* Caption */}
                          <div className="bg-white/70 p-3 rounded-lg">
                            <p className="font-semibold text-blue-800 mb-1">✏️ Caption:</p>
                            <ul className="list-disc list-inside space-y-1 ml-2">
                              <li>
                                <strong>Draft/Posting Error:</strong> Có thể edit caption trực tiếp
                              </li>
                              <li>
                                <strong>Use/Posted:</strong> Read Only, không edit được
                              </li>
                              <li>Hiển thị: Chars (số ký tự) và Hashtag (số lượng #)</li>
                            </ul>
                          </div>

                          {/* Media Files */}
                          <div className="bg-white/70 p-3 rounded-lg">
                            <p className="font-semibold text-amber-800 mb-1">🖼️ Media Files:</p>
                            <ul className="list-disc list-inside space-y-1 ml-2">
                              <li>
                                <strong>Tải thêm:</strong> Chỉ khi Draft/Posting Error (tối đa 10 files cùng lúc)
                              </li>
                              <li>
                                <strong>Xóa media:</strong> Click nút X trên mỗi ảnh/video
                              </li>
                              <li>
                                <strong>Sắp xếp:</strong> Kéo thả (drag & drop) để đổi vị trí
                              </li>
                              <li>
                                <strong>Read Only:</strong> Use/Posted không chỉnh sửa được
                              </li>
                            </ul>
                          </div>

                          {/* Carousel Social */}
                          <div className="bg-white/70 p-3 rounded-lg">
                            <p className="font-semibold text-pink-800 mb-1">📱 Carousel Social:</p>
                            <ul className="list-disc list-inside space-y-1 ml-2">
                              <li>Xem preview các media theo thứ tự từ Trái → Phải</li>
                              <li>Số thứ tự hiển thị: 1 → 2 → 3 → ...</li>
                              <li>Giúp kiểm tra thứ tự hiển thị trước khi đăng</li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Caption - Empty State */}
                  <div className="px-6 pt-4">
                    <div className="rounded-xl border-2 border-[#E5E7EB]">
                      <div className="px-5 py-3 bg-[#F0F4F8] border-b border-[#E5E7EB] flex items-center gap-2">
                        <FileText className="h-4 w-4 text-[#91bfb4]" />
                        <span className="text-sm font-semibold text-[#1E293B]">Caption</span>
                        <span className="ml-1 px-2.5 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold">
                          Chars: 0
                        </span>
                        <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700 text-xs font-semibold">
                          Hashtag: 0
                        </span>
                      </div>
                      <div className="p-6">
                        <div className="flex items-center justify-center py-8 text-gray-400 italic">
                          <FileX className="h-8 w-8 mr-2" />
                          No caption added yet...
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Media Files - Empty State */}
                  <div className="px-6 pt-4">
                    <div className="rounded-xl border-2 border-[#E5E7EB]">
                      <div className="px-5 py-3 bg-[#F0F4F8] border-b border-[#E5E7EB] flex items-center gap-2">
                        <ImageIcon className="h-4 w-4 text-[#91bfb4]" />
                        <span className="text-sm font-semibold text-[#1E293B]">Media Files</span>
                        <span className="ml-1 px-2.5 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-semibold">
                          Image: 0
                        </span>
                        <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-700 text-xs font-semibold">
                          Video: 0
                        </span>
                      </div>
                      <div className="p-6" style={{ minHeight: "220px" }}>
                        <div>
                          <label
                            htmlFor="upload-media-empty"
                            className="flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg cursor-pointer hover:from-purple-600 hover:to-pink-600 transition-all shadow-md hover:shadow-lg"
                          >
                            <Upload className="h-5 w-5" />
                            <span className="font-bold text-base">Tải thêm ảnh/video</span>
                            <input
                              id="upload-media-empty"
                              type="file"
                              multiple
                              accept="image/*,video/*"
                              onChange={() => {
                                console.log("[v0] Upload in empty state")
                              }}
                              className="hidden"
                              disabled
                            />
                          </label>
                          <p className="text-center text-xs text-gray-500 mt-2 font-medium">
                            Tối đa upload 10 files cùng lúc. - Hỗ trợ: JPG, PNG, MP4, MOV
                          </p>
                        </div>

                        <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
                          <FileImage className="h-12 w-12 mx-auto text-gray-300 mb-2" />
                          <p className="text-sm text-gray-400">No media files</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Carousel Social - Empty State */}
                  <div className="px-6 pt-4">
                    <div className="mt-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-purple-200">
                      <div className="px-5 py-3 bg-white/80 backdrop-blur-sm border-b border-purple-200 flex items-center gap-2">
                        <Instagram className="h-5 w-5 text-purple-600" />
                        <span className="text-sm font-semibold text-purple-900">
                          Carousel Social{" "}
                          <span className="text-purple-400 font-normal">(bắt đầu chọn từ Trái → Phải)</span>
                        </span>
                        <span className="ml-auto text-xs text-purple-600 font-medium">0 slides</span>
                      </div>
                      <div className="p-6">
                        <div className="text-center py-8">
                          <FileImage className="h-12 w-12 mx-auto text-purple-300 mb-2" />
                          <p className="text-sm text-purple-600">No media to preview</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={bulkCreateModal.isOpen}
        onOpenChange={(open) => {
          if (!open) {
            setBulkCreateModal({
              isOpen: false,
              ideaNicheId: null,
              folderType: null,
              folderName: null,
              quantity: 5,
            })
          }
        }}
      >
        <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-purple-600" />
              Bulk Create Posts
            </DialogTitle>
            <DialogDescription>
              Create multiple posts at once for{" "}
              <span className="font-semibold text-purple-600">{bulkCreateModal.folderName}</span>
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Number of Posts</label>
              <Input
                type="number"
                min="1"
                max="100"
                value={bulkCreateModal.quantity}
                onChange={(e) =>
                  setBulkCreateModal((prev) => ({ ...prev, quantity: Number.parseInt(e.target.value) || 1 }))
                }
                placeholder="Enter quantity (1-100)"
                className="w-full"
              />
              <p className="text-xs text-gray-500">
                All posts will be created with status <span className="font-semibold">Draft</span>
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-1">
              <p className="text-sm font-medium text-blue-900">Quick Tips:</p>
              <ul className="text-xs text-blue-700 space-y-1 list-disc list-inside">
                <li>Each post will have a unique caption: "Draft 1", "Draft 2", etc.</li>
                <li>Media files will be empty - you can upload them individually later</li>
                <li>You can edit each post's caption and upload media after creation</li>
                <li>Recommended: 5-20 posts per batch</li>
              </ul>
            </div>
          </div>

          <DialogFooter className="flex gap-2">
            <Button
              variant="outline"
              onClick={() =>
                setBulkCreateModal({
                  isOpen: false,
                  ideaNicheId: null,
                  folderType: null,
                  folderName: null,
                  quantity: 5,
                })
              }
            >
              Cancel
            </Button>
            <Button onClick={handleBulkCreatePosts} className="bg-purple-600 hover:bg-purple-700 text-white">
              Create Posts
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <Dialog
        open={deleteConfirmation.isOpen}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteConfirmation({ isOpen: false, type: null, postId: null, position: null, postNumber: null })
          }
        }}
      >
        <div
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{
            top: deleteConfirmation.position?.top,
            left: deleteConfirmation.position?.left,
            transform: `translate(${deleteConfirmation.position?.left ? "-100%" : "0%"}, ${deleteConfirmation.position?.top ? "-100%" : "0%"})`,
            display: deleteConfirmation.isOpen ? "flex" : "none",
            position: "absolute", // Necessary for absolute positioning relative to dialog content
            width: "auto", // Adjust width as needed
            height: "auto", // Adjust height as needed
          }}
        >
          <DialogContent className="p-0 shadow-lg border-none" style={{ padding: "0px", width: "auto" }}>
            <Card className="border-0 shadow-none">
              <CardHeader className="p-4 pb-2 flex items-center justify-between">
                <CardTitle className="text-lg font-semibold">Confirm Deletion</CardTitle>
                <button onClick={() => setDeleteConfirmation({ ...deleteConfirmation, isOpen: false })}>
                  <X className="h-5 w-5 text-gray-500 hover:text-gray-700" />
                </button>
              </CardHeader>
              <CardContent className="p-4 pt-2">
                {deleteConfirmation.type === "bulk" ? (
                  <p className="text-sm text-gray-700">
                    Are you sure you want to delete {selectedIds.length} selected item(s)? This action cannot be undone.
                  </p>
                ) : (
                  <p className="text-sm text-gray-700">
                    Are you sure you want to delete post #{deleteConfirmation.postNumber}? This action cannot be undone.
                  </p>
                )}
              </CardContent>
              <CardFooter className="p-4 pt-2 flex items-center justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => setDeleteConfirmation({ ...deleteConfirmation, isOpen: false })}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={() => {
                    if (deleteConfirmation.type === "bulk") {
                      handleBulkDelete()
                    } else if (deleteConfirmation.type === "single" && deleteConfirmation.postId) {
                      handleDeletePost(deleteConfirmation.postId)
                    }
                    setDeleteConfirmation({ ...deleteConfirmation, isOpen: false })
                  }}
                >
                  Delete
                </Button>
              </CardFooter>
            </Card>
          </DialogContent>
        </div>
      </Dialog>
    </div>
  )
}
